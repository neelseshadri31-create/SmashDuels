from playwright.sync_api import sync_playwright
import time
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1360,'height':820})
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.8)
    pg.click('#btn-vs'); time.sleep(0.4); pg.click('#sel-fight'); time.sleep(3.2)
    pg.screenshot(path='/tmp/sky.png', timeout=9000)
    b.close()
