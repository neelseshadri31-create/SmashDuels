from playwright.sync_api import sync_playwright
import time, json
res=[]
def log(n,ok,info=''): res.append((n,ok,info)); print(('PASS' if ok else 'FAIL'),n,info)

with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.0)
    pg.click('#btn-vs'); time.sleep(0.25); pg.click('#sel-fight'); time.sleep(0.4)
    pg.evaluate("""()=>{const m=window.__match;m.state='play';m.rules.items='none';m.updateItems=function(){};
      const c=m.fighters[1];c.ai=null;c.isCPU=false;c.x=900;c.y=0;c.damage=0;c.eliminated=false;
      window.__hit=(key,dist=48)=>{
        const a=window.__match.fighters[0], b=window.__match.fighters[1], m=window.__match;
        a.x=0;a.y=0;a.vx=0;a.vy=0;a.onGround=true;a.state='idle';a.action=null;a.hitstun=0;a.facing=1;a.damage=0;
        a.charging=false;a.chargeT=0;a.forceRelease=false;a.hitlag=0;a.hitIds=new Set();a.prevInput={};a.stunT=0;a.shieldHP=0;a.onPlatform=null;a.dropThroughT=0;a.respawnT=0;a.spawnProtect=0;a.invincT=0;a.usedUpB=false;a.airJumpsLeft=a.def.stats.airJumps;a.jumpsLeft=a.def.stats.jumps;a.inputBuffer={attack:0,special:0,jump:0,shield:0,grab:0};
        a.readInput({});
        b.x=dist;b.y=0;b.vx=0;b.vy=0;b.onGround=true;b.state='idle';b.action=null;b.hitstun=0;b.damage=0;b.shieldHP=0;
        a.readInput({attack:true}); a.startAttack(key,m);
        const d0=b.damage;
        for(let k=0;k<90;k++){
          a.readInput({attack:k<2});                    // tap then release -> uncharged smash
          a.update(m); b.update(m); INPUT.endFrame();
          if(a.state!=='attack'&&k>4)break;}
        return {d0,d1:+b.damage.toFixed(2),st:b.state,vx:+b.vx.toFixed(2),vy:+b.vy.toFixed(2)};
      };
    }""")
    time.sleep(0.3)

    moves=[('jab',40),('ftilt',46),('dtilt',46),('utilt',46),('dashattack',46),('fsmash',52),('usmash',44),('dsmash',46)]
    for mv,d in moves:
        r=pg.evaluate("([mv,d])=>window.__hit(mv,d)",[mv,d])
        log(f"D-{mv} increments damage", r['d1']>0, f"{r['d0']}→{r['d1']} (kb {r['vx']},{r['vy']})")

    # accumulation across several hits on one target
    r=pg.evaluate("""()=>{const m=window.__match,a=m.fighters[0],b=m.fighters[1];
      b.damage=0;b.x=48;b.y=0;b.onGround=true;b.shieldHP=0;
      const seq=[];
      for(let n=0;n<5;n++){
        a.x=0;a.y=0;a.state='idle';a.action=null;a.hitstun=0;a.facing=1;a.actionT=0;a.hitlag=0;a.hitIds=new Set();a.prevInput={};a.inputBuffer={attack:0,special:0,jump:0,shield:0,grab:0};
        b.hitstun=0;b.state='idle';b.vx=0;b.vy=0;b.x=48;b.y=0;b.onGround=true;b.hitlag=0;
        a.readInput({attack:true}); a.startAttack('jab',m);
        for(let k=0;k<70;k++){a.readInput({attack:k<2});a.update(m);b.update(m);INPUT.endFrame(); if(a.state!=='attack'&&k>3)break;}
        seq.push(+b.damage.toFixed(1));
      }
      return seq;}""")
    log("D1 damage accumulates across hits", all(r[i]<r[i+1] for i in range(len(r)-1)), str(r))

    # HUD text matches fighter damage
    r=pg.evaluate("""()=>{const m=window.__match;const b=m.fighters[1];b.damage=0;b.x=48;b.y=0;
      const a=m.fighters[0];a.x=0;a.y=0;a.state='idle';a.action=null;a.actionT=0;a.facing=1;b.hitstun=0;b.shieldHP=0;
      a.startAttack('fsmash',m);
      for(let k=0;k<60;k++){a.update(m);b.update(m);INPUT.endFrame(); if(a.charging)a.readInput({}); if(a.state!=='attack'&&k>4)break;}
      const hud=document.querySelectorAll('#hud-slots .hud-slot, #hud-slots .slot, #hud-slots > *');
      // let the render loop refresh the throttled HUD before reading it
      return {dmg:+b.damage.toFixed(1)};}""")
    time.sleep(0.45)   # let the throttled HUD refresh in the render loop
    r['hud'] = pg.evaluate("()=>{const e=document.querySelectorAll('#hud-slots .pct')[1];return e?e.textContent:'(none)';}")
    log("D1b HUD text shows the new damage", str(int(r['dmg'])) == str(r['hud']), f"{r['dmg']} vs '{r['hud']}'")

    # shield absorbs damage but still increments slightly / shield HP drops
    r=pg.evaluate("""()=>{const m=window.__match,a=m.fighters[0],b=m.fighters[1];
      for(const f of [a,b]){f.hitlag=0;f.hitstun=0;f.stunT=0;f.action=null;f.state='idle';f.shieldStun=0;
        f.respawnT=0;f.spawnProtect=0;f.invincT=0;f.vx=0;f.vy=0;f.onGround=true;f.actionT=0;f.hitIds=new Set();f.prevInput={};f.shieldHP=0;}
      a.x=0;a.y=0;a.facing=1;a.inputBuffer={attack:0,special:0,jump:0,shield:0,grab:0};
      b.x=48;b.y=0;b.damage=0;b.shieldHP=60;b.shieldT=0;b.state='shield';
      a.readInput({attack:true}); a.startAttack('fsmash',m);
      let absorbed=false;
      for(let k=0;k<90;k++){
        a.readInput({attack:k<2});
        b.readInput({shield:true});      // player holds shield
        a.update(m); b.update(m); INPUT.endFrame();
        if(b.shieldHP<55){ absorbed=true; break; }
      }
      return {dmg:+b.damage.toFixed(1),hp:+b.shieldHP.toFixed(1),st:b.state,absorbed};}""")
    log("D7 shield blocks damage & drains shield HP", r['absorbed'] and r['dmg']==0 and r['hp']<58, f"dmg {r['dmg']} shieldHP {r['hp']}")

    # projectile damage counts
    r=pg.evaluate("""()=>{const m=window.__match,a=m.fighters[0],b=m.fighters[1];
      b.x=200;b.y=0;b.damage=0;b.shieldHP=0;b.hitstun=0;b.state='idle';b.onGround=true;
      a.x=0;a.y=0;a.facing=1;a.state='idle';a.action=null;a.actionT=0;
      const nb=(b.stats&&b.stats.taken)||0;
      m.rules.items='none'; m.projectiles.length=0;
      for(const f of [a,b]){f.hitlag=0;f.hitstun=0;f.stunT=0;f.action=null;f.state='idle';f.shieldHP=0;f.shieldStun=0;
        f.respawnT=0;f.spawnProtect=0;f.invincT=0;f.vx=0;f.vy=0;f.onGround=true;f.actionT=0;f.prevInput={};f.eliminated=false;f.stocks=3;}
      a.x=-220;a.y=0;a.facing=1;a.cooldowns={};a.specialData=null;
      b.x=40;b.y=0;b.damage=0;
      a.readInput({special:true}); a.startSpecial('n',m);
      for(let k=0;k<200;k++){ a.readInput({}); a.update(m); b.update(m);
        for(let i=m.projectiles.length-1;i>=0;i--){const p=m.projectiles[i];p.update(m);if(p.dead)m.projectiles.splice(i,1);}
        if(b.damage>0) break; }
      return {dmg:+b.damage.toFixed(1),st:a.state,proj:(m.projectiles||[]).length};}""")
    log("D8 projectile special damages target", r['dmg']>0, str(r))

    # knockback grows with damage
    r=pg.evaluate("""()=>{const m=window.__match,a=m.fighters[0],b=m.fighters[1];
      const kb=(dmg)=>{ b.damage=dmg;b.x=48;b.y=0;b.onGround=true;b.vx=0;b.vy=0;b.hitstun=0;b.shieldHP=0;b.state='idle';
        a.x=0;a.y=0;a.state='idle';a.action=null;a.actionT=0;a.facing=1;a.hitstun=0;a.hitlag=0;a.hitIds=new Set();a.prevInput={};a.inputBuffer={attack:0,special:0,jump:0,shield:0,grab:0};
        b.hitlag=0;b.vy=0;
        a.readInput({attack:true}); a.startAttack('fsmash',m);
        for(let k=0;k<90;k++){a.readInput({attack:k<2});a.update(m);b.update(m);INPUT.endFrame(); if(b.hitstun>0)break;}
        return Math.hypot(b.vx,b.vy); };
      return [0,60,120,200].map(d=>+kb(d).toFixed(1));}""")
    log("D-ko knockback scales with damage", all(r[i]<r[i+1] for i in range(len(r)-1)), str(r))
    print('ERRS', errs[:3])
    br.close()
print('\n== SUMMARY ==')
for n,ok,_ in res: print(('PASS' if ok else 'FAIL'), n)
