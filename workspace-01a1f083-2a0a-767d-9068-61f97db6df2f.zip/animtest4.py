from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw
import time
states=['idle','walk','run','jump','fall','crouch','shield','attack','hitstun']
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1440,'height':860})
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.0)
    pg.click('#btn-vs'); time.sleep(0.25); pg.click('#sel-fight'); time.sleep(0.4)
    pg.evaluate("()=>{const m=window.__match;m.state='play';m.rules.items='none';const c=m.fighters[1];c.ai=null;c.isCPU=false;c.x=400;m.updateItems=function(){};}")
    time.sleep(1.2)
    pg.evaluate("()=>{window.__match.paused=true;}")
    crops=[]
    for st in states:
        pg.evaluate("""(st)=>{const f=window.__match.fighters[0];
          f.x=0;f.y=0;f.vx=0;f.vy=0;f.hitstun=0;f.onGround=true;f.facing=1;f.actionT=0;f.action=null;f.state='idle';
          if(st==='attack'){f.state='attack';f.action={key:'fsmash',startup:12,active:4,dur:40};f.actionT=14;}
          else if(st==='shield'){f.shieldHP=60;f.state='shield';}
          else if(st==='hitstun'){f.hitstun=30;f.state='hitstun';}
          else if(st==='jump'){f.y=-70;f.onGround=false;f.state='jump';}
          else if(st==='fall'){f.y=-70;f.onGround=false;f.state='fall';}
          else f.state=st;
          f.groundDist = f.onGround?0:70;
        }""",st); time.sleep(0.2)
        v=pg.evaluate("()=>{const m=window.__match,f=m.fighters[0];const z=m.cam.zoom;return [m.W/2+z*(f.x-m.cam.x), m.H/2+z*(f.y-m.cam.y), f.state];}")
        pg.screenshot(path='/tmp/s.png')
        im=Image.open('/tmp/s.png'); sx,sy=v[0],v[1]
        crops.append((f'{st}', im.crop((int(sx)-75,int(sy)-195,int(sx)+75,int(sy)+25))))
        print(st,'->',v[2])
    W=sum(c.width for _,c in crops);H=max(c.height for _,c in crops)+22
    mon=Image.new('RGB',(W,H),(18,28,48)); d=ImageDraw.Draw(mon); x=0
    for st,c in crops:
        mon.paste(c,(x,22)); d.text((x+4,5),st,fill=(255,240,180)); x+=c.width
    mon.save('/tmp/anim_states.png')
    br.close()
