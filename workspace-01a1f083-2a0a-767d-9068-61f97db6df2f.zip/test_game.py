from playwright.sync_api import sync_playwright
import time, json

errors=[]
with sync_playwright() as p:
    b = p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    pg = b.new_page(viewport={'width':1440,'height':860})
    pg.on('console', lambda m: errors.append(('console:'+m.type, m.text)) if m.type in ('error','warning') else None)
    pg.on('pageerror', lambda e: errors.append(('pageerror', str(e))))
    pg.goto('http://127.0.0.1:8080/index.html', wait_until='load')
    time.sleep(1.2)
    pg.screenshot(path='/tmp/shot_title.png')
    print('TITLE ok, visible screens:', pg.eval_on_selector_all('.screen.active','els=>els.map(e=>e.id)'))

    # go to character select
    pg.click('#btn-vs'); time.sleep(0.7)
    pg.screenshot(path='/tmp/shot_select.png')

    # choose astra for slot 0
    pg.click('.fcell[data-key="astra"]'); time.sleep(0.3)
    pg.screenshot(path='/tmp/shot_select2.png')

    # start fight
    pg.click('#sel-fight'); time.sleep(1.2)
    pg.screenshot(path='/tmp/shot_intro.png')
    # let it play
    pg.keyboard.down('KeyD')
    time.sleep(1.0)
    pg.keyboard.up('KeyD')
    pg.keyboard.press('KeyF')
    time.sleep(0.25)
    pg.keyboard.press('KeyG')
    time.sleep(1.5)
    pg.screenshot(path='/tmp/shot_play1.png')
    # check state
    st = pg.evaluate("() => { const m = Game && window.match; return null }")
    pg.keyboard.press('KeyW'); time.sleep(0.4)
    pg.keyboard.press('KeyF'); time.sleep(0.6)
    pg.screenshot(path='/tmp/shot_play2.png')
    time.sleep(3.0)
    pg.screenshot(path='/tmp/shot_play3.png')
    b.close()

print('--- errors ---')
for e in errors[:30]: print(e)
print('count', len(errors))
