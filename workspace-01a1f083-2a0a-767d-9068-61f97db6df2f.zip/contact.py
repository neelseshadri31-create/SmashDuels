from PIL import Image, ImageDraw
import numpy as np, sys

def runs(vals, thresh, gap):
    out=[]; start=None; last=None
    for i,v in enumerate(vals):
        if v>thresh:
            if start is None: start=i
            last=i
        else:
            if start is not None and i-last>gap:
                out.append((start,last)); start=None
    if start is not None: out.append((start,last))
    return out

def cells_for(path, W, H):
    im = Image.open(path).convert('RGB')
    a = np.array(im).astype(np.float32)
    m = a.max(axis=2) > 44
    cols = {'L':(0,int(W*0.445)), 'M':(int(W*0.445),int(W*0.685)), 'R':(int(W*0.685),W)}
    result=[]
    for cname,(x0,x1) in cols.items():
        sub = m[:, x0:x1]
        bands = runs(sub.sum(axis=1), 1, 5)
        ri=0
        for (y0,y1) in bands:
            if y1-y0 < 20: continue
            band = sub[y0:y1+1]
            cw = runs(band.sum(axis=0), 0, 3)
            for (cx0,cx1) in cw:
                if cx1-cx0 < 10: continue
                seg = band[:, cx0:cx1+1]
                ys = np.where(seg.any(axis=1))[0]
                h = ys.max()-ys.min()+1
                if h < 22: continue
                result.append(dict(region=cname,row=ri,x=int(x0+cx0),y=int(y0+ys.min()),w=int(cx1-cx0+1),h=int(h)))
            ri+=1
    return im, result

def sheet(path, out, W, H):
    im, cells = cells_for(path, W, H)
    CELL=150; MARGIN=26; COLS=8
    rows=(len(cells)+COLS-1)//COLS
    canvas=Image.new('RGB',(COLS*CELL, rows*(CELL+MARGIN)+20),(20,22,30))
    d=ImageDraw.Draw(canvas)
    for i,c in enumerate(cells):
        cx=(i%COLS)*CELL; cy=(i//COLS)*(CELL+MARGIN)+20
        spr = im.crop((c['x'],c['y'],c['x']+c['w'],c['y']+c['h']))
        spr.thumbnail((CELL-10,CELL-10), Image.LANCZOS)
        canvas.paste(spr,(cx+(CELL-spr.width)//2, cy+(CELL-spr.height)//2))
        d.text((cx+3, cy-20), f"{i}:{c['region']}{c['row']} {c['x']},{c['y']} {c['w']}x{c['h']}", fill=(150,210,255))
    canvas.save(out)
    print(out, len(cells), 'cells')

sheet('roster/grim_the_colossus_spritesheet.png','/tmp/contact_grim.png',1264,848)
sheet('roster/valor_the_swordsman_spritesheet.png','/tmp/contact_valor.png',1536,1024)
