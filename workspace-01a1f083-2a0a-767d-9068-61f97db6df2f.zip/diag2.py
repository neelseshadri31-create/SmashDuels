from playwright.sync_api import sync_playwright
import time, json
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1200,'height':760})
    pg.on('pageerror',lambda e: print('ERR',e))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.7)
    pg.click('#btn-vs'); time.sleep(0.25); pg.click('#sel-fight'); time.sleep(0.5)
    pg.evaluate("()=>{const m=window.__match;m.state='play';m.fighters[1].ai=null;m.fighters[1].isCPU=false;}")

    def rd(label):
        d = pg.evaluate("()=>window.RR.diag()")
        print(label, {k:d[k] for k in ['st','act','actT','buf','canAct','hj','onG','y','vy']})

    # simulate pressing G (special) for one frame then releasing
    print(pg.evaluate("()=>{const m=window.__match;const f=m.fighters[0];f.state='idle';f.x=0;f.y=0;f.action=null;return true}"))
    base = {'left':False,'right':False,'up':False,'down':False,'attack':False,'special':False,'jump':False,'shield':False,'grab':False}
    d0 = pg.evaluate("(raw)=>window.RR.feed(raw,1)", base)
    print('idle:', {k:d0[k] for k in ['st','buf','canAct']})
    d1 = pg.evaluate("(raw)=>window.RR.feed(raw,1)", {**base,'special':True})
    print('press special 1 frame:', {k:d1[k] for k in ['st','act','buf','canAct','hj','hl']})
    d2 = pg.evaluate("(raw)=>window.RR.feed(raw,3)", {**base,'special':True})
    print('hold special 3 frames:', {k:d2[k] for k in ['st','act','actT']})
    b.close()
