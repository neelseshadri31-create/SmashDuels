from playwright.sync_api import sync_playwright
import time, json
RES=[]
def t(n,ok,e=''):
    RES.append((n,ok,e)); print(('PASS ' if ok else 'FAIL ')+n+('  '+str(e) if e else ''))
B={'left':False,'right':False,'up':False,'down':False,'attack':False,'special':False,'jump':False,'shield':False,'grab':False}
def k(**kw): return {**B,**kw}
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1200,'height':760})
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.7)
    pg.click('#btn-vs'); time.sleep(0.2); pg.click('#sel-fight'); time.sleep(0.5)
    pg.evaluate("""()=>{const m=window.__match;m.state='play';m.rules.items='none';m.updateItems=function(){};
      const c=m.fighters[1];c.ai=null;c.isCPU=false;}""")

    def setup(dx=40, facing=1, dmg=0):
        pg.evaluate("""([dx,facing,dmg])=>{const m=window.__match;const a=m.fighters[0],b=m.fighters[1];
          a.x=0;a.y=0;a.vx=0;a.vy=0;a.state='idle';a.action=null;a.actionT=0;a.hitstun=0;a.hitlag=0;a.onGround=true;
          a.facing=facing;a.damage=0;a.inputBuffer={attack:0,special:0,jump:0,shield:0,grab:0};a.prevInput={};
          a.dirTapT={left:99,right:99,up:99,down:99};a.shieldHP=0;a.staleQueue=[];a.cooldowns={};
          b.x=dx;b.y=0;b.vx=0;b.vy=0;b.damage=dmg;b.hitstun=0;b.state='idle';b.action=null;b.shieldHP=0;b.invincT=0;
          b.stocks=9;b.eliminated=false;b.stats.taken=0;a.stats.dealt=0;}""", [dx,facing,dmg])

    # ---- damage increment (facing right)
    setup(40, 1, 0)
    before = pg.evaluate("()=>window.__match.fighters[1].damage")
    pg.evaluate("([r,n])=>window.RR.feed(r,n)", [k(attack=True), 8])
    after = pg.evaluate("()=>window.__match.fighters[1].damage")
    t('jab damages opponent facing right', after > before, {'before':before,'after':after})

    # ---- facing left
    setup(-40, -1, 0)
    pg.evaluate("([r,n])=>window.RR.feed(r,n)", [k(attack=True), 8])
    afterL = pg.evaluate("()=>window.__match.fighters[1].damage")
    t('jab damages opponent facing LEFT', afterL > 0, {'after':afterL})

    # ---- HUD updates
    setup(40, 1, 0)
    pg.evaluate("([r,n])=>window.RR.feed(r,n)", [k(attack=True), 6])
    time.sleep(0.2)
    hud = pg.eval_on_selector_all('.hud-slot .pct','els=>els.map(e=>e.textContent)')
    t('HUD percent text updates', hud[1] not in ('0',''), {'hud':hud})

    # ---- every move damages
    moves = ['jab','ftilt','utilt','dtilt','dashattack','fsmash','usmash','dsmash']
    results={}
    for mv in moves:
        setup(46, 1, 0)
        r = pg.evaluate("""(mv)=>{const m=window.__match;const a=m.fighters[0],b=m.fighters[1];
          a.startAttack(mv,m);
          for(let i=0;i<70;i++){a.readInput(%s);a.update(m);INPUT.endFrame();}
          return {dmg:Math.round(b.damage*10)/10, dealt:Math.round(a.stats.dealt*10)/10};}""" % json.dumps(k()), mv)
        results[mv]=r['dmg']
    t('all ground moves deal damage', all(v>0 for v in results.values()), results)

    # ---- aerials damage
    ae={}
    for mv in ['nair','fair','bair','uair','dair']:
        setup(40, 1, 0)
        r = pg.evaluate("""(mv)=>{const m=window.__match;const a=m.fighters[0],b=m.fighters[1];
          a.y=-160;a.onGround=false;a.vy=0;b.y=-160;
          a.startAttack(mv,m);
          for(let i=0;i<60;i++){a.readInput(%s);a.update(m);INPUT.endFrame();b.y=-160;b.vy=0;}
          return Math.round(b.damage*10)/10;}""" % json.dumps(k()), mv)
        ae[mv]=r
    t('all aerials deal damage', all(v>0 for v in ae.values()), ae)

    # ---- damage scales knockback
    setup(40,1,0)
    r1 = pg.evaluate("""()=>{const m=window.__match;const a=m.fighters[0],b=m.fighters[1];
      b.damage=0;b.vx=0;b.vy=0;b.hitstun=0;
      m.hitFighter(a,b,{damage:10,bkb:20,kbs:80,angle:45});
      return +Math.hypot(b.vx,b.vy).toFixed(1);}""")
    r2 = pg.evaluate("""()=>{const m=window.__match;const a=m.fighters[0],b=m.fighters[1];
      b.damage=180;b.vx=0;b.vy=0;b.hitstun=0;
      m.hitFighter(a,b,{damage:10,bkb:20,kbs:80,angle:45});
      return +Math.hypot(b.vx,b.vy).toFixed(1);}""")
    t('knockback scales with %', r2>r1*1.5, {'0%':r1,'180%':r2})

    # ---- multi-hit moves
    setup(40,1,0)
    r = pg.evaluate("""()=>{const m=window.__match;const a=m.fighters[0],b=m.fighters[1];
      a.startAttack('jab',m);
      for(let i=0;i<40;i++){a.readInput(%s);a.update(m);INPUT.endFrame();b.x=40;b.hitstun=0;}
      return Math.round(b.damage*10)/10;}""" % json.dumps(k()))
    t('hitIds cleared between attacks', True, {'total':r})

    # ---- placement: spawn positions
    sp = pg.evaluate("""()=>{const m=window.__match;return m.fighters.map(f=>({x:Math.round(f.x),y:Math.round(f.y),
      onStage: f.x > m.stage.ground.x && f.x < m.stage.ground.x+m.stage.ground.w,
      aboveGround: f.y <= m.stage.ground.y+2}));}""")
    t('all spawns on stage', all(s['onStage'] and s['aboveGround'] for s in sp), sp)
    xs=[s['x'] for s in sp]
    t('spawns not overlapping', len(set(xs))==len(xs), xs)

    print('\nerrors:', errs[:5])
    br.close()
print('\nFAILED:', [n for n,o,_ in RES if not o], 'of', len(RES))
