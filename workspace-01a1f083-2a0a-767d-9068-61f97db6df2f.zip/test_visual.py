from playwright.sync_api import sync_playwright
import time, sys
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':860})
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.8)
    pg.click('#btn-vs'); time.sleep(0.4)
    # pick 4 fighters: grim cpu, astra, vesper
    pg.click('#add-slot'); time.sleep(0.2)
    pg.click('.fcell[data-key="vesper"]'); time.sleep(0.2)
    pg.click('#add-slot'); time.sleep(0.2)
    pg.click('.fcell[data-key="rook"]'); time.sleep(0.2)
    pg.click('#sel-fight'); time.sleep(3.2)
    pg.screenshot(path='/tmp/v1.png')
    for i,(k,d) in enumerate([('KeyD',0.6),('KeyF',0.4),('KeyG',0.6),('KeyW',0.5)]):
        pg.keyboard.down(k); time.sleep(d); pg.keyboard.up(k); time.sleep(0.15)
        pg.screenshot(path=f'/tmp/v{i+2}.png')
    time.sleep(2)
    pg.screenshot(path='/tmp/v6.png')
    b.close()
print('errors', errs[:6], len(errs))
