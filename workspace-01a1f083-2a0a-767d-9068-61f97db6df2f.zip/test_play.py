from playwright.sync_api import sync_playwright
import time
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':860})
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.on('console',lambda m: errs.append('console:'+m.text) if m.type=='error' else None)
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.9)
    pg.click('#btn-vs'); time.sleep(0.4)
    pg.click('#sel-fight'); time.sleep(0.4)
    pg.screenshot(path='/tmp/g_intro.png')
    time.sleep(1.8)
    pg.screenshot(path='/tmp/g_play0.png')
    # walk right and attack
    pg.keyboard.down('KeyD'); time.sleep(0.9); pg.keyboard.up('KeyD')
    pg.keyboard.press('KeyF'); time.sleep(0.35)
    pg.screenshot(path='/tmp/g_play1.png')
    pg.keyboard.down('KeyW'); time.sleep(0.08); pg.keyboard.press('KeyF'); pg.keyboard.up('KeyW'); time.sleep(0.4)
    pg.screenshot(path='/tmp/g_play2.png')
    pg.keyboard.press('KeyG'); time.sleep(0.5)
    pg.screenshot(path='/tmp/g_play3.png')
    time.sleep(2.5)
    pg.screenshot(path='/tmp/g_play4.png')
    info = pg.evaluate("()=>{const c=document.getElementById('game-canvas');return {w:c.width,h:c.height};}")
    print('canvas', info)
    b.close()
print('errors:', errs[:12], 'n=',len(errs))
