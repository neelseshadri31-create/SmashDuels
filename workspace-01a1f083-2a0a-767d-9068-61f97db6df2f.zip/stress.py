from playwright.sync_api import sync_playwright
import time
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    print('=== 4-player max items, all stages, long run ===')
    for sk in ['skyshrine','foundry','hollow']:
        pg.evaluate("""(sk)=>{const cast=['valor','grim','astra','vesper'].map((k,i)=>({key:k,palIdx:i,isCPU:true,team:i%2}));
          Game.startMatch({rules:{...DEFAULT_RULES,mode:'classic',items:'high',stock:5,time:600,teams:true},cast,stageKey:sk,metaMode:null});
          window.__match.state='play';}""", sk)
        for _ in range(18): pg.evaluate("()=>RR.step(150)"); time.sleep(0.04)
        print(f"  {sk:12s}", pg.evaluate("""()=>{const m=window.__match;
          return {st:m.state,frame:m.frame,items:m.items.length,proj:m.projectiles.length,
                  summons:m.summons.length,mines:m.mines.length,
                  states:m.fighters.map(f=>f.state+(f.eliminated?'(X)':'')),
                  stocks:m.fighters.map(f=>f.stocks)};}"""))
    print('errors after stress:', errs[:8], 'count', len(errs))

    print('\n=== every special, every fighter, all 4 directions ===')
    r=pg.evaluate("""()=>{const out=[];
      const cast=[{key:'valor',palIdx:0,isCPU:false,team:0},{key:'grim',palIdx:0,isCPU:true,team:1}];
      Game.startMatch({rules:{...DEFAULT_RULES,mode:'classic',items:'none',stock:3,time:300},cast,stageKey:'terminal',metaMode:null});
      const m=window.__match; m.state='play'; m.rules.items='none';
      const a=m.fighters[0],b=m.fighters[1];b.ai=null;b.isCPU=false;
      for(const key of ['valor','grim','astra','vesper','rook']){
        for(const dir of ['n','s','u','d']){
          for(const f of [a,b]){f.hitlag=0;f.hitstun=0;f.stunT=0;f.action=null;f.state='idle';f.shieldHP=0;
            f.respawnT=0;f.spawnProtect=0;f.invincT=0;f.vx=0;f.vy=0;f.onGround=true;f.actionT=0;f.prevInput={};
            f.eliminated=false;f.stocks=3;f.y=0;}
          a.key=key;a.def=FIGHTERS[key];a.pal=FIGHTERS[key].palettes[0];
          a.x=0;a.y=0;a.facing=1;a.cooldowns={};a.specialData=null;a.usedUpB=false;
          b.x=140;b.y=0;b.damage=0;
          let err=null;
          try{
            a.readInput({special:true}); a.startSpecial(dir,m);
            for(let k=0;k<70;k++){ a.readInput({}); a.update(m); b.update(m);
              for(let i=m.projectiles.length-1;i>=0;i--){const pr=m.projectiles[i];pr.update(m);if(pr.dead)m.projectiles.splice(i,1);}
              if(a.state!=='special')break; }
          }catch(e){ err=String(e); }
          out.push({key,dir,err,final:a.state,onG:a.onGround,y:+a.y.toFixed(0)});
        }
      }
      return out;}""")
    bad=[x for x in r if x['err']]
    sunk=[x for x in r if x['y']>4]
    print(f"  tested {len(r)} specials | errors={len(bad)} | sank below floor={len(sunk)}")
    for x in bad[:5]: print('   ERR',x)
    for x in sunk[:5]: print('   SUNK',x)
    print('total errors:', len(errs))
    br.close()
