from playwright.sync_api import sync_playwright
import time
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1400,'height':840})
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.8)
    # 4-player with items on skyshrine
    pg.click('#btn-vs'); time.sleep(0.3)
    pg.click('#add-slot'); time.sleep(0.15); pg.click('.fcell[data-key="astra"]'); time.sleep(0.15)
    pg.click('#add-slot'); time.sleep(0.15); pg.click('.fcell[data-key="vesper"]'); time.sleep(0.15)
    pg.click('#sel-fight'); time.sleep(1.0)
    pg.evaluate("()=>{const m=window.__match;m.state='play';m.rules.items='high';}")
    pg.evaluate("()=>window.RR.makeAllCPU()")
    for i in range(20):
        st = pg.evaluate("()=>window.RR.step(300)")
        time.sleep(0.03)
        if i==8: pg.screenshot(path='/tmp/lp_1.png', timeout=9000)
        if st['state']!='play': break
    time.sleep(1.4)
    pg.screenshot(path='/tmp/lp_2.png', timeout=9000)
    print('final', st)
    print('errors', errs[:4], len(errs))
    b.close()
