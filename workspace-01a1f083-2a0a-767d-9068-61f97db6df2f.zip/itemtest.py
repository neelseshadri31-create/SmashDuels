from playwright.sync_api import sync_playwright
import time, json
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':800})
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.7)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.6)
    pg.evaluate("()=>{ const m=window.__match; m.state='play'; m.makeAllCPU; }")
    pg.evaluate("()=>{ const m=window.__match; m.rules.items='high'; m.itemTimer=5; }")
    r = pg.evaluate("""()=>{
      const m=window.__match;
      const log=[];
      for(let i=0;i<1200 && m.state==='play';i++){ m.update(); INPUT.endFrame(); }
      const held = m.items.filter(it=>it.heldBy).length;
      const healed = m.fighters.map(f=>f.damage);
      return {items:m.items.length, held, proj:m.projectiles.length,
              itemTypes:m.items.map(i=>i.type), dmg:healed.map(d=>Math.round(d)),
              kos:m.fighters.map(f=>f.stats.kos)};
    }""")
    print(json.dumps(r))
    pg.screenshot(path='/tmp/items.png')
    print('errors', errs[:4])
    b.close()
