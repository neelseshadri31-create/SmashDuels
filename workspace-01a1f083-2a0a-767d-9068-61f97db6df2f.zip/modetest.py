from playwright.sync_api import sync_playwright
import time
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1360,'height':820})
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.9)
    print('title mode buttons:', pg.eval_on_selector_all('.modebtn','els=>els.map(e=>e.dataset.mode)'))
    # targets mode
    pg.click('.modebtn[data-mode="targets"]'); time.sleep(0.4)
    pg.click('#sel-fight'); time.sleep(2.2)
    st = pg.evaluate("()=>({targets: window.__match.targets ? window.__match.targets.length : 0, state: window.__match.state})")
    print('targets:', st)
    pg.screenshot(path='/tmp/m_targets.png', timeout=9000)
    # hit a target: teleport player next to one and attack
    pg.evaluate("""()=>{ const m=window.__match; const t=m.targets[0]; const f=m.fighters[0]; f.x=t.x-30; f.y=t.y+40; }""")
    pg.keyboard.press('KeyF'); time.sleep(0.5)
    pg.screenshot(path='/tmp/m_targets2.png', timeout=9000)
    print('dead targets after swing:', pg.evaluate("()=>window.__match.targets.filter(t=>t.dead).length"))
    print('errors', errs[:5])
    b.close()
