from playwright.sync_api import sync_playwright
from PIL import Image
import time
states = ['idle','walk','run','jump','fall','crouch','shield','attack','hitstun']
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1440,'height':860})
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.0)
    pg.click('#btn-vs'); time.sleep(0.25); pg.click('#sel-fight'); time.sleep(0.4)
    pg.evaluate("()=>{const m=window.__match;m.state='play';m.rules.items='none';const c=m.fighters[1];c.ai=null;c.isCPU=false;c.x=400;m.updateItems=function(){};}")
    time.sleep(1.2)
    crops=[]
    for st in states:
        pg.evaluate("""(st)=>{const m=window.__match;const f=m.fighters[0];
          f.x=0;f.y=0;f.vx=0;f.vy=0;f.hitstun=0;f.onGround=true;f.facing=1;f.damage=0;f.actionT=0;
          if(st==='attack'){f.state='idle';f.startAttack('fsmash',m);}else{f.state=st;f.action=null;}
          if(st==='walk')f.vx=2; if(st==='run')f.vx=5;
          if(st==='shield'){f.shieldHP=60;}
          if(st==='hitstun'){f.hitstun=30;}
          if(st==='jump'){f.y=-60;f.onGround=false;f.vy=-2;}
          if(st==='fall'){f.y=-60;f.onGround=false;f.vy=2;}
        }""", st); time.sleep(0.28)
        v=pg.evaluate("()=>{const m=window.__match,f=m.fighters[0];return {st:f.state,sc:(()=>{const z=m.cam.zoom;return [m.W/2+z*(f.x-m.cam.x), m.H/2+z*(f.y-m.cam.y)];})()};}")
        pg.screenshot(path='/tmp/s.png')
        im=Image.open('/tmp/s.png'); sx,sy=v['sc']
        crops.append((st, im.crop((int(sx)-70,int(sy)-190,int(sx)+70,int(sy)+30))))
        print(st, v['st'], [round(x) for x in v['sc']])
    W=sum(c.width for _,c in crops); H=max(c.height for _,c in crops)+22
    from PIL import ImageDraw
    mon=Image.new('RGB',(W,H),(18,28,48)); d=ImageDraw.Draw(mon); x=0
    for st,c in crops:
        mon.paste(c,(x,22)); d.text((x+4,5),st,fill=(255,240,180)); x+=c.width
    mon.save('/tmp/anim_states.png')
    br.close()
