from playwright.sync_api import sync_playwright
import time
cases = {
 "hold down while landing on deck": "f.readInput({down:true});",
 "hold down+right (fastfall drift)": "f.readInput({down:true,right:true});",
 "hold shield while landing": "f.readInput({shield:true});",
 "hold jump while landing": "f.readInput({jump:true});",
 "idle landing": "f.readInput({});",
}
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.6)
    for name, inp in cases.items():
        r=pg.evaluate("""([inp])=>{const m=window.__match;m.state='play';m.rules.items='none';
          const f=m.fighters[0];m.fighters[1].ai=null;m.fighters[1].x=900;
          f.x=340;f.y=-400;f.vx=0;f.vy=6;f.onGround=false;f.onPlatform=null;f.state='fall';
          f.hitstun=0;f.hitlag=0;f.dropThroughT=0;f.respawnDropT=0;f.ledge=null;f.prevInput={};
          let wentBelow=false, minY=0;
          for(let k=0;k<80;k++){
            eval(inp); f.update(m); INPUT.endFrame();
            if(f.y>8) wentBelow=true;
            if(f.y<minY) minY=f.y;
          }
          return {y:+f.y.toFixed(1),st:f.state,onG:f.onGround,wentBelow,elim:f.eliminated,stocks:f.stocks};}""", [inp])
        flag = 'FAIL' if (r['wentBelow'] or r['elim']) else 'ok  '
        print(f'{flag} {name:36s} {r}')
    br.close()
