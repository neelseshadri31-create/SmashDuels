from playwright.sync_api import sync_playwright
import time, json
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':800})
    errs=[]
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.7)
    pg.click('#btn-vs'); time.sleep(0.3)
    pg.click('#sel-fight'); time.sleep(0.9)
    # force past the 3-2-1 intro
    pg.evaluate("()=>{ const m=window.__match; m.state='play'; m.stateT=0; }")
    print('makeAllCPU', pg.evaluate("()=>window.RR.makeAllCPU()"))
    pg.evaluate("()=>{ window.__match.rules.items='high'; }")
    rows=[]
    for i in range(40):
        r = pg.evaluate("()=>window.RR.step(600)")
        rows.append(r)
        if r['state']!='play': break
    for r in rows[:6]+rows[-3:]:
        print(json.dumps(r))
    print('errors:', errs[:5], 'n=', len(errs))
    b.close()
