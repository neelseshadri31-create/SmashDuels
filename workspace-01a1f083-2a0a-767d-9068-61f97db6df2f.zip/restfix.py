from playwright.sync_api import sync_playwright
import time, math
res=[]
def log(n,ok,info=''): res.append((n,ok,info)); print(('PASS' if ok else 'FAIL'),n,info)
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.5)
    pg.evaluate("""()=>{const m=window.__match;m.state='play';m.rules.items='none';
      const b=m.fighters[1];b.ai=null;b.isCPU=false;b.x=900;
      window.__R=(a,b2)=>{for(const f of [a,b2]){f.hitlag=0;f.hitstun=0;f.stunT=0;f.action=null;f.state='idle';f.shieldHP=0;f.shieldStun=0;f.respawnT=0;f.spawnProtect=0;f.invincT=0;f.vx=0;f.vy=0;f.onGround=true;f.actionT=0;f.prevInput={};f.eliminated=false;f.stocks=3;f.damage=0;}};}""")
    # D2: hitbox correct when facing LEFT
    r=pg.evaluate("""()=>{const m=window.__match,a=m.fighters[0],b=m.fighters[1];
      __R(a,b); a.x=0;a.y=0;a.facing=-1;a.hitIds=new Set(); a.state='idle';a.action=null;
      b.x=-52;b.y=0;b.damage=0;
      a.readInput({attack:true}); a.startAttack('fsmash',m);
      for(let k=0;k<60;k++){a.readInput({attack:k<2});a.update(m);b.update(m);INPUT.endFrame(); if(b.hitstun>0)break;}
      return {dmg:+b.damage.toFixed(1),facing:a.facing};}""")
    log("D2 hitbox correct facing left", r['dmg']>0, str(r))

    # D3: multi-hit move (uair/dtilt have repeat windows?) - test same move re-hits after cooldown
    r=pg.evaluate("""()=>{const m=window.__match,a=m.fighters[0],b=m.fighters[1];
      __R(a,b);a.x=0;a.y=0;a.facing=1;a.hitIds=new Set();b.x=44;b.y=0;
      a.readInput({attack:true});a.startAttack('jab',m);
      let hits=0,last=0;
      for(let k=0;k<300;k++){
        const tap=(k%16)<2;
        a.readInput({attack:tap}); a.update(m); b.update(m); INPUT.endFrame();
        if(b.damage>last){hits++;last=b.damage;}
        // keep the target in range so every swing can connect
        b.hitstun=0;b.hitlag=0;b.vx=0;b.vy=0;b.x=44;b.y=0;b.state='idle';b.action=null;
      }
      return {hits,dmg:+b.damage.toFixed(1)};}""")
    log("D3 repeated jabs each land (hit-id resets)", r['hits']>=3, str(r))

    # D5: NaN guard with extreme weight/damage
    r=pg.evaluate("""()=>{const m=window.__match,a=m.fighters[0],b=m.fighters[1];
      __R(a,b);b.weight=1;b.damage=999;a.x=0;a.y=0;a.facing=1;a.hitIds=new Set();b.x=50;b.y=0;
      m.hitFighter(a,b,{damage:20,bkb:30,kbs:90,angle:40});
      const ok=isFinite(b.vx)&&isFinite(b.vy)&&isFinite(b.damage);
      b.weight=100; return {ok,vx:b.vx,vy:b.vy,dmg:b.damage};}""")
    log("D5 no NaN at extreme weight/damage", r['ok'], str(r))

    # D9: first active frame deals damage
    r=pg.evaluate("""()=>{const m=window.__match,a=m.fighters[0],b=m.fighters[1];
      __R(a,b);a.x=0;a.y=0;a.facing=1;a.hitIds=new Set();b.x=44;b.y=0;
      a.readInput({attack:true});a.startAttack('jab',m);
      let firstActive=-1,hitFrame=-1;
      for(let k=0;k<30;k++){a.readInput({attack:k<2});a.update(m);b.update(m);INPUT.endFrame();
        const t=a.actionT-a.action.startup;
        if(firstActive<0&&t>=0)firstActive=k;
        if(hitFrame<0&&b.damage>0)hitFrame=k;
        if(b.hitstun>0)break;}
      return {firstActive,hitFrame,lost:hitFrame-firstActive};}""")
    log("D9 damage lands on first active frame", r['lost']<=0, str(r))

    # D10: counter returns damage
    r=pg.evaluate("""()=>{const m=window.__match,a=m.fighters[0],b=m.fighters[1];
      __R(a,b);a.x=0;a.y=0;a.facing=1;a.hitIds=new Set();
      b.x=40;b.y=0;b.facing=-1;b.hitIds=new Set();b.damage=0;
      a.readInput({special:true});a.startSpecial('d',m);       // guardian stance
      for(let k=0;k<14;k++){a.readInput({});a.update(m);INPUT.endFrame();}
      b.readInput({attack:true});b.startAttack('jab',m);
      for(let k=0;k<40;k++){a.readInput({});b.readInput({attack:k<2});a.update(m);b.update(m);INPUT.endFrame();}
      return {attackerDmg:+b.damage.toFixed(1), defenderDmg:+a.damage.toFixed(1)};}""")
    log("D10 counter reflects damage to attacker", r['attackerDmg']>0, str(r))

    # E2: results stats
    r=pg.evaluate("""()=>{const m=window.__match;return {keys:Object.keys(m.fighters[0].stats),stats:JSON.stringify(m.fighters[0].stats)};}""")
    log("E2 fighter stats tracked", 'kos' in r['keys'] and 'taken' in r['keys'], r['stats'])

    # E4: pause stops simulation
    r=pg.evaluate("""()=>{const m=window.__match;m.state='play';m.paused=false;
      const f=m.fighters[0];f.x=0;f.vx=3;
      m.paused=true; const x0=f.x;
      for(let k=0;k<30;k++)m.update(1);
      return {moved:+(f.x-x0).toFixed(2)};}""")
    log("E4 pause freezes simulation", abs(r['moved'])<0.01, str(r))

    # E6: touch controls present
    r=pg.evaluate("""()=>{const el=document.getElementById('touch-controls');
      const btns=el?el.querySelectorAll('.touchbtn').length:0;
      const wired=[...(el?el.querySelectorAll('.touchbtn'):[])].every(b=>b.dataset.touch);
      return {exists:!!el, buttons:btns, wired};}""")
    log("E6 touch controls wired", r['exists'] and r['buttons']>=8 and r['wired'], str(r))

    # E3: item pickup radius
    r=pg.evaluate("""()=>{const m=window.__match;m.rules.items='low';
      const a=m.fighters[0];a.x=0;a.y=0;a.state='idle';a.held=null;
      m.items.length=0;
      m.spawnItem ? null : null;
      return {hasSpawn: typeof m.spawnItem==='function'};}""")
    log("E3 item spawn API", r['hasSpawn'], str(r))
    print('ERRS', errs[:4])
    br.close()
print('\n== SUMMARY ==')
for n,ok,_ in res: print(('PASS' if ok else 'FAIL'), n)
