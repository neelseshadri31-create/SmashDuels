from playwright.sync_api import sync_playwright
import time, traceback
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':800})
    pg.on('pageerror', lambda e: print('PAGEERROR:', e.stack[:1200] if hasattr(e,'stack') else e))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.8)
    pg.click('#btn-vs'); time.sleep(0.3)
    pg.click('#add-slot'); time.sleep(0.2)
    pg.click('#add-slot'); time.sleep(0.2)
    print('slots active:', pg.evaluate("()=>Array.from(document.querySelectorAll('#slot-tabs button')).map(b=>b.textContent)"))
    pg.click('#sel-fight'); time.sleep(1.5)
    b.close()
