from playwright.sync_api import sync_playwright
import time
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.6)
    # --- TEST 1: drop through a soft platform, then see if we land on the main deck
    r=pg.evaluate("""()=>{const m=window.__match;m.state='play';m.rules.items='none';
      const f=m.fighters[0],p=m.stage.platforms[0];
      m.fighters[1].ai=null;m.fighters[1].x=900;
      f.x=p.x;f.y=p.y-120;f.vx=0;f.vy=2;f.onGround=false;f.onPlatform=-1;f.state='fall';f.hitstun=0;
      for(let k=0;k<40;k++){f.readInput({});f.update(m);INPUT.endFrame();}
      const landed=+f.y.toFixed(1), onPlat=!!f.onPlatform;
      // now press down to drop through
      let log=[];
      for(let k=0;k<70;k++){
        f.readInput({down:true}); f.update(m); INPUT.endFrame();
        if(k%5===0) log.push({k,y:+f.y.toFixed(1),st:f.state,onG:f.onGround,dropT:f.dropThroughT});
      }
      return {landed,onPlat,final:{y:+f.y.toFixed(1),st:f.state,onG:f.onGround},log};}""")
    print('landed on soft plat:', r['landed'], r['onPlat'])
    for l in r['log']: print('  ', l)
    print('  FINAL:', r['final'])
    print('errors', errs[:3])
    br.close()
