from playwright.sync_api import sync_playwright
import time
from collections import defaultdict
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.5)
    pg.evaluate("()=>{window.__match.state='play';}")
    time.sleep(1.0)
    pg.evaluate("""()=>{window.__picks=[];const m=window.__match;
      const orig=Sprites.pickFrame;
      Sprites.pickFrame=function(f,t){const v=orig(f,t); window.__picks.push({k:f.key,p:v,st:f.state}); return v;};}""")
    time.sleep(2.4)
    d=pg.evaluate("()=>window.__picks")
    per=defaultdict(list)
    for x in d: per[(x['k'],x['st'])].append(x['p'])
    for k,v in per.items():
        trans=sum(1 for i in range(1,len(v)) if v[i]!=v[i-1])
        print(f"{k[0]:7s} {k[1]:8s} draws={len(v):4d} changes={trans:4d}  seq={v[:16]}")
    print('TOTAL PICKS CAPTURED:', len(d))
    br.close()
