from playwright.sync_api import sync_playwright
import time, json
FAIL=[]
def check(name, cond, extra=''):
    print(('PASS ' if cond else 'FAIL ')+name+(' '+str(extra) if extra else ''))
    if not cond: FAIL.append(name)

with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1360,'height':820})
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.8)
    check('title loads', pg.is_visible('#screen-title'))

    # records
    pg.click('#btn-records'); time.sleep(0.4)
    check('records screen', pg.is_visible('#screen-records'))
    pg.click('#records-back'); time.sleep(0.3)

    # help
    pg.click('#btn-help'); time.sleep(0.4)
    check('help screen', pg.is_visible('#screen-help'))
    pg.click('#help-back'); time.sleep(0.3)

    # select screen + all fighters clickable
    pg.click('#btn-vs'); time.sleep(0.4)
    check('select screen', pg.is_visible('#screen-select'))
    for k in ['grim','astra','vesper','rook','valor']:
        pg.click(f'.fcell[data-key="{k}"]'); time.sleep(0.12)
        name = pg.inner_text('#hero-name')
        check(f'pick {k}', name.lower().startswith(k[:4]), name)
    # palette swap
    pg.click('.swatch[data-p="2"]'); time.sleep(0.15)
    check('palette swap', pg.eval_on_selector('.swatch[data-p="2"]','e=>e.classList.contains("on")'))

    # stage select
    pg.click('#sel-stage'); time.sleep(0.5)
    check('stage screen', pg.is_visible('#screen-stage'))
    n = pg.eval_on_selector_all('.scell','els=>els.length')
    check('6 stages', n==6, n)
    canvases_ok = pg.eval_on_selector_all('.scell canvas','els=>els.every(c=>c.width>0)')
    check('stage thumbnails render', canvases_ok)
    pg.click('.scell[data-k="foundry"]'); time.sleep(0.2)
    check('stage picked', pg.eval_on_selector('.scell.sel','e=>e.dataset.k')=='foundry')
    pg.click('#stage-back'); time.sleep(0.3)

    # rules
    pg.click('#sel-rules'); time.sleep(0.4)
    check('rules screen', pg.is_visible('#screen-rules'))
    pg.eval_on_selector_all('.seg[data-k="mode"] button', "els=>els.find(e=>e.dataset.v==='time').click()")
    time.sleep(0.2)
    pg.eval_on_selector_all('.seg[data-k="items"] button', "els=>els.find(e=>e.dataset.v==='high').click()")
    time.sleep(0.2)
    pg.eval_on_selector_all('.seg[data-k="teams"] button', "els=>els.find(e=>e.dataset.v==='1').click()")
    time.sleep(0.2)
    pg.click('#rules-go'); time.sleep(1.2)
    st = pg.evaluate("()=>{const m=window.__match;return {mode:m.rules.mode, items:m.rules.items, teams:m.rules.teams, stage:m.stage.key};}")
    check('rules applied', st['mode']=='time' and st['items']=='high' and st['teams']==True, st)
    check('stage applied', st['stage']=='foundry', st)
    check('timer visible in time mode', pg.eval_on_selector('#hud-timer','e=>getComputedStyle(e).display')!='none')
    try: pg.screenshot(path='/tmp/t_foundry.png', timeout=8000)
    except Exception: pass

    # pause / resume
    pg.click('#btn-pause'); time.sleep(0.4)
    check('pause overlay', pg.eval_on_selector('#pause-overlay','e=>e.classList.contains("on")'))
    pg.click('#btn-resume'); time.sleep(0.3)
    check('resume', not pg.eval_on_selector('#pause-overlay','e=>e.classList.contains("on")'))

    # simulate a full time-mode match quickly
    pg.evaluate("()=>{const m=window.__match; m.state='play';}")
    pg.evaluate("()=>window.RR.makeAllCPU()")
    res=None
    for i in range(80):
        res = pg.evaluate("()=>window.RR.step(180)")
        time.sleep(0.02)
        if res['state']!='play': break
    check('time match ends', res['state']=='over', res['frame'])
    time.sleep(1.6)
    check('results screen shown', pg.is_visible('#screen-results'))
    try: pg.screenshot(path='/tmp/t_results.png', timeout=8000)
    except Exception as e: print('screenshot skip', e)

    # rematch
    pg.click('#btn-results-again'); time.sleep(1.2)
    check('rematch starts', pg.evaluate("()=>!!window.__match && window.__match.state!=='over'"))
    pg.click('#btn-pause'); time.sleep(0.3)
    pg.click('#btn-quit'); time.sleep(0.6)
    check('quit to title', pg.is_visible('#screen-title'))

    check('no runtime errors', len(errs)==0, errs[:3])
    b.close()
print('\nFAILURES:', FAIL)
