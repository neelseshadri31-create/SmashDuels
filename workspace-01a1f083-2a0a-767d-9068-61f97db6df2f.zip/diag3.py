from playwright.sync_api import sync_playwright
import time, json
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.6)
    pg.evaluate("()=>{window.__match.state='play';}")
    time.sleep(1.0)
    # Log pickFrame output + y over ~90 rendered frames
    r=pg.evaluate("""()=>{
      const log=[];
      const m=window.__match;
      const f=m.fighters[0];
      const orig=Sprites.pickFrame;
      window.__frames=[];
      Sprites.pickFrame=function(fg,t){const v=orig(fg,t); window.__frames.push(v); return v;};
      // sample real time progression
      for(let k=0;k<90;k++){ m.update(); log.push({k,t:Math.round(m.time),y:+f.y.toFixed(1),st:f.state,onG:f.onGround}); }
      Sprites.pickFrame=orig;
      return {log, frames:window.__frames.slice(0,60)};}""")
    print('frame picks:', r['frames'][:40])
    print()
    for l in r['log'][::6]: print(l)
    print('errors', errs[:3])
    br.close()
