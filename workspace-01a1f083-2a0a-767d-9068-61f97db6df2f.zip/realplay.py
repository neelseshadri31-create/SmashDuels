from playwright.sync_api import sync_playwright
import time
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1440,'height':860})
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.5)
    pg.evaluate("()=>{window.__match.state='play';}")
    time.sleep(0.4)
    d0=pg.evaluate("()=>+window.__match.fighters[1].damage.toFixed(1)")
    # walk right, jump, attack — real keys
    pg.keyboard.down('KeyD'); time.sleep(0.55)
    pg.keyboard.down('Space'); time.sleep(0.12); pg.keyboard.up('Space'); time.sleep(0.45)
    pg.keyboard.down('KeyF'); time.sleep(0.09); pg.keyboard.up('KeyF'); time.sleep(0.4)
    pg.keyboard.up('KeyD'); time.sleep(0.3)
    st=pg.evaluate("""()=>{const m=window.__match,f=m.fighters[0];
      return {x:+f.x.toFixed(0),y:+f.y.toFixed(0),st:f.state,onG:f.onGround,
              camX:+m.cam.x.toFixed(0),camZ:+m.cam.zoom.toFixed(2)};}""")
    print('after walk/jump/attack:', st)
    # special + grab
    pg.keyboard.press('KeyG'); time.sleep(0.7)
    print('after special: proj=', pg.evaluate("()=>window.__match.projectiles.length"),
          'state=', pg.evaluate("()=>window.__match.fighters[0].state"))
    pg.keyboard.press('KeyV'); time.sleep(0.5)
    print('after grab: state=', pg.evaluate("()=>window.__match.fighters[0].state"))
    # shield
    pg.keyboard.down('KeyC'); time.sleep(0.4)
    print('shielding:', pg.evaluate("()=>{const f=window.__match.fighters[0];return {st:f.state,hp:+f.shieldHP.toFixed(0)};}"))
    pg.keyboard.up('KeyC'); time.sleep(0.3)
    # let a CPU match run for a while and watch for errors
    pg.evaluate("()=>{RR.makeAllCPU();}")
    for _ in range(6):
        pg.evaluate("()=>RR.step(120)"); time.sleep(0.12)
    print('late:', pg.evaluate("()=>{const m=window.__match;return {state:m.state,frame:m.frame,dmg:m.fighters.map(f=>+f.damage.toFixed(0)),stocks:m.fighters.map(f=>f.stocks)};}"))
    pg.screenshot(path='/tmp/realplay.png')
    print('ERRORS:', errs[:5])
    br.close()
