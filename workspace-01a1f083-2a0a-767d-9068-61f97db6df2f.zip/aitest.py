from playwright.sync_api import sync_playwright
import time, json
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':800})
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.7)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.6)
    pg.evaluate("()=>{ const m=window.__match; m.state='play'; }")
    r = pg.evaluate("""()=>{
      const m=window.__match; const f=m.fighters[1];
      const trace=[];
      for(let i=0;i<300;i++){
        const raw = f.ai.think(m);
        f.readInput(raw); f.update(m); INPUT.endFrame();
        if(i%20===0) trace.push({i, st:f.state, x:Math.round(f.x), plan:f.ai.plan, atk:raw.attack, jmp:raw.jump, timer:f.ai.timer, cd:f.ai.attackCd});
      }
      return trace;
    }""")
    for t in r: print(t)
    b.close()
