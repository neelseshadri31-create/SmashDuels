from PIL import Image
import numpy as np, os, json

SHEETS = {
 'valor': 'roster/valor_the_swordsman_spritesheet.png',
 'grim':  'roster/grim_the_colossus_spritesheet.png',
 'astra': 'roster/astra_the_starweaver_spritesheet.png',
 'vesper':'roster/vesper_the_shade_spritesheet.png',
 'rook':  'roster/rook_the_hexshot_spritesheet.png',
}

def mask_of(im):
    a = np.array(im.convert('RGB')).astype(np.float32)
    lum = a.max(axis=2)
    return lum > 44

def runs(vals, thresh, gap):
    out=[]; start=None; last=None
    for i,v in enumerate(vals):
        if v>thresh:
            if start is None: start=i
            last=i
        else:
            if start is not None and i-last>gap:
                out.append((start,last)); start=None
    if start is not None: out.append((start,last))
    return out

for key,path in SHEETS.items():
    im = Image.open(path)
    W,H = im.size
    m = mask_of(im)
    print('='*90); print(key, W, H)
    cols = {'left': (0, int(W*0.44)), 'mid': (int(W*0.445), int(W*0.685)), 'right': (int(W*0.69), W)}
    for cname,(x0,x1) in cols.items():
        sub = m[:, x0:x1]
        rowws = sub.sum(axis=1)
        bands = runs(rowws, 1, 5)
        print(f'-- {cname} col x{x0}-{x1}')
        for (y0,y1) in bands:
            if y1-y0 < 20: continue
            band = sub[y0:y1+1]
            colws = band.sum(axis=0)
            cr = runs(colws, 0, 4)
            cells=[]
            for (a,b) in cr:
                if b-a < 8: continue
                seg = band[:, a:b+1]
                rows_any = seg.any(axis=1)
                ys = np.where(rows_any)[0]
                h = ys.max()-ys.min()+1
                cells.append((x0+a, y0+ys.min(), b-a+1, h))
            cells = [c for c in cells if c[3] >= 22 and c[2] >= 10]
            print(f'   y{y0}-{y1} (h{y1-y0+1}) cells={len(cells)} ' + ' '.join(f'{c[2]}x{c[3]}' for c in cells))
