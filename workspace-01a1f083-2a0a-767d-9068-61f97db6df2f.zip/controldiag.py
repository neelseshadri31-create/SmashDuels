from playwright.sync_api import sync_playwright
import time, json
RES=[]
def t(name, ok, extra=''):
    RES.append((name, ok, extra)); print(('PASS ' if ok else 'FAIL ')+name+('  '+str(extra) if extra else ''))

with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1360,'height':820})
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.8)
    pg.click('#btn-vs'); time.sleep(0.25); pg.click('#sel-fight'); time.sleep(0.6)
    # enter play state, freeze CPU
    pg.evaluate("()=>{const m=window.__match;m.state='play';m.fighters[1].ai=null;m.fighters[1].isCPU=false;m.rules.items='none';}")

    def reset():
        pg.evaluate("""()=>{const m=window.__match;const f=m.fighters[0];
          f.x=0;f.y=0;f.vx=0;f.vy=0;f.state='idle';f.action=null;f.hitstun=0;f.onGround=true;
          f.inputBuffer={attack:0,special:0,jump:0,shield:0,grab:0};f.prevInput={};
          f.shieldHP=0;f.airJumpsLeft=f.def.stats.airJumps;f.usedUpB=false;f.onPlatform=null;}""")

    def probe():
        return pg.evaluate("""()=>{const f=window.__match.fighters[0];
          return {st:f.state, act:f.action?f.action.type:null, key:f.action?f.action.key:null,
                  y:Math.round(f.y), vx:+f.vx.toFixed(2), vy:+f.vy.toFixed(2), onG:f.onGround,
                  shield:Math.round(f.shieldHP), jumps:f.airJumpsLeft, dir:f.facing};}""")

    # --- A1/A2: press W once, see if it jumps AND also creates an attack buffer
    reset()
    pg.keyboard.down('KeyW'); time.sleep(0.06); pg.keyboard.up('KeyW')
    time.sleep(0.15)
    s = probe(); t('W tap -> jump', s['st'] in ('jump','air','fall','doublejump') or s['y']<-2, s)

    # press W + F together -> should be up attack, or jump? check conflict
    reset()
    pg.keyboard.down('KeyW'); pg.keyboard.down('KeyF'); time.sleep(0.05)
    pg.keyboard.up('KeyW'); pg.keyboard.up('KeyF'); time.sleep(0.12)
    s = probe(); t('W+F resolves to ONE action (not jump+attack)', True, s)

    # --- attack on ground
    reset()
    pg.keyboard.press('KeyF'); time.sleep(0.1)
    s = probe(); t('F on ground -> jab', s['st']=='attack' and s['key']=='jab', s)

    # --- hold attack: should not repeatedly re-trigger after action
    reset()
    pg.keyboard.down('KeyF'); time.sleep(0.8)
    s1 = probe()
    pg.keyboard.up('KeyF')
    t('holding F does not spam attacks', s1['st']!='attack' or s1['act']=='move', s1)

    # --- dash attack
    reset()
    pg.keyboard.down('KeyD'); time.sleep(0.55)
    st_before = probe()
    pg.keyboard.press('KeyF'); time.sleep(0.12)
    s = probe()
    pg.keyboard.up('KeyD')
    t('running + F -> dash attack', s['key']=='dashattack', {'before':st_before['st'],'after':s})

    # --- side tilt vs smash
    reset()
    pg.keyboard.down('KeyD'); time.sleep(0.35)
    pg.keyboard.press('KeyF'); time.sleep(0.1)
    s1 = probe()
    pg.keyboard.up('KeyD'); time.sleep(0.4)
    reset()
    pg.keyboard.down('KeyD'); pg.keyboard.press('KeyF'); time.sleep(0.1)
    s2 = probe(); pg.keyboard.up('KeyD')
    t('neutral+hover D + F -> fsmash or ftilt', s2['key'] in ('fsmash','ftilt'), s2)

    # --- crouch + down
    reset()
    pg.keyboard.down('KeyS'); time.sleep(0.2)
    s = probe(); pg.keyboard.up('KeyS')
    t('S -> crouch', s['st']=='crouch', s)

    # --- shield
    reset()
    pg.keyboard.down('KeyC'); time.sleep(0.15)
    s = probe()
    t('C -> shield active', s['shield']>0, s)
    # roll out of shield
    pg.keyboard.down('KeyD'); time.sleep(0.12)
    s2 = probe()
    pg.keyboard.up('KeyD'); pg.keyboard.up('KeyC')
    t('shield + direction -> roll', s2['st']=='roll', s2)

    # --- grab
    reset()
    pg.keyboard.press('KeyV'); time.sleep(0.1)
    s = probe(); t('V -> grab', s['st']=='grab', s)

    # --- specials
    reset()
    pg.keyboard.press('KeyG'); time.sleep(0.1)
    s = probe(); t('G -> neutral special', s['st']=='special', s)
    time.sleep(0.5)
    reset()
    pg.keyboard.down('KeyD'); pg.keyboard.press('KeyG'); time.sleep(0.12)
    s = probe(); pg.keyboard.up('KeyD')
    t('D+G -> side special', s['act']=='special' and s.get('key')!='neutral', s)

    # --- jump in air = double jump
    reset()
    pg.keyboard.press('KeyW'); time.sleep(0.25)
    j1 = probe()
    pg.keyboard.press('KeyW'); time.sleep(0.12)
    j2 = probe()
    t('double jump works', j2['jumps'] < j1['jumps'] or j2['vy'] < j1['vy'], {'j1':j1['jumps'],'j2':j2['jumps']})

    print('\nerrors:', errs[:5])
    b.close()
print('\n=== SUMMARY ===')
for n,ok,e in RES:
    if not ok: print('FAILED:', n, e)
print('total', len(RES), 'failed', sum(1 for _,o,_ in RES if not o))
