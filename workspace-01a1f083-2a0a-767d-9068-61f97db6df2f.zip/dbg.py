from playwright.sync_api import sync_playwright
import time
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':800})
    logs=[]
    pg.on('console',lambda m: logs.append((m.type,m.text)))
    pg.on('pageerror',lambda e: logs.append(('pageerror',str(e))))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1)
    pg.click('#btn-vs'); time.sleep(0.5)
    print('funcs:', pg.evaluate("()=>Object.keys(Game)"))
    print('screen-match exists:', pg.evaluate("()=>!!document.getElementById('screen-match')"))
    try:
        pg.click('#sel-fight'); time.sleep(0.3)
    except Exception as e:
        print('click err', e)
    print('active screens:', pg.evaluate("()=>Array.from(document.querySelectorAll('.screen.active')).map(e=>e.id)"))
    print('has match?', pg.evaluate("()=> !!(window.__m) "))
    print('logs', logs[-6:])
    b.close()
