from playwright.sync_api import sync_playwright
import time
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1440,'height':860})
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.0)
    pg.click('#btn-vs'); time.sleep(0.25); pg.click('#sel-fight'); time.sleep(0.4)
    pg.evaluate("()=>{const m=window.__match;m.state='play';m.rules.items='none';const c=m.fighters[1];c.ai=null;c.isCPU=false;c.x=400;m.updateItems=function(){};}")
    time.sleep(1.0)
    print('sprites ready:', pg.evaluate("()=>Sprites.ready('valor')"))
    # capture a sheet of states
    states = ['idle','walk','run','jump','fall','crouch','shield','attack','hitstun']
    imgs=[]
    for st in states:
        pg.evaluate("""(st)=>{const m=window.__match;const f=m.fighters[0];
          f.x=0;f.y=0;f.vx=0;f.vy=0;f.state=st;f.action=null;f.hitstun=0;f.onGround=true;f.facing=1;f.damage=0;
          if(st==='attack'){f.startAttack('fsmash',m);}
          if(st==='walk')f.vx=2;
          if(st==='run')f.vx=5;
          if(st==='crouch')f.state='crouch';
          if(st==='shield'){f.shieldHP=60;f.state='shield';}
          if(st==='hitstun'){f.hitstun=30;f.state='hitstun';}
          if(st==='jump'){f.y=-60;f.onGround=false;f.vy=-6;}
          if(st==='fall'){f.y=-60;f.onGround=false;f.vy=5;}
        }""", st)
        time.sleep(0.18)
        pg.screenshot(path=f'/tmp/a_{st}.png', timeout=9000)
    # montage the character region
    from PIL import Image
    crops=[]
    for st in states:
        im=Image.open(f'/tmp/a_{st}.png')
        # character is centred around x=720,y=520 in 1440x860
        c=im.crop((620,380,820,640))
        crops.append((st,c))
    W=sum(c.width for _,c in crops); H=max(c.height for _,c in crops)+24
    mon=Image.new('RGB',(W,H),(20,30,50))
    from PIL import ImageDraw
    d=ImageDraw.Draw(mon); x=0
    for st,c in crops:
        mon.paste(c,(x,24)); d.text((x+4,6),st,fill=(255,240,180)); x+=c.width
    mon.save('/tmp/anim_states.png')
    print('errors:', errs[:4])
    br.close()
