from playwright.sync_api import sync_playwright
import time
from collections import defaultdict
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.5)
    pg.evaluate("()=>{window.__match.state='play';}")
    time.sleep(0.8)
    # hook the module-level draw function through the returned object
    pg.evaluate("""()=>{window.__picks=[];
      const orig=Sprites.drawSpriteFighter;
      Sprites.drawSpriteFighter=function(ctx,f,t){
        window.__picks.push({k:f.key,st:f.state,p:Sprites.pickFrame(f,t)});
        return orig.apply(Sprites,arguments);
      };}""")
    time.sleep(2.2)
    d=pg.evaluate("()=>window.__picks")
    print('captured', len(d))
    per=defaultdict(list)
    for x in d: per[(x['k'],x['st'])].append(x['p'])
    for k,v in sorted(per.items()):
        trans=sum(1 for i in range(1,len(v)) if v[i]!=v[i-1])
        print(f"{k[0]:7s} {k[1]:9s} draws={len(v):4d} changes={trans:4d}  seq={v[:18]}")
    br.close()
