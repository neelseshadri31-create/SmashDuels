from playwright.sync_api import sync_playwright
import time
STAGES=['skyshrine','terminal','foundry','cometreach','hollow','range']
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    for sk in STAGES:
        pg.evaluate("""(sk)=>{const cast=['valor','grim','astra','vesper'].map((k,i)=>({key:k,palIdx:i,isCPU:true,team:0}));
          Game.startMatch({rules:{...DEFAULT_RULES,mode:'classic',items:'high',stock:3,time:300},cast,stageKey:sk,metaMode:null});
          window.__match.state='play';
          window.__V=[];
          const m=window.__match;
          const orig=m.update.bind(m);
          m.update=function(){orig();
            if(this.state!=='play')return;
            const gd=this.stage.ground;
            this.fighters.forEach((f,i)=>{
              if(f.eliminated||f.state==='respawn')return;
              const insideX = f.x>gd.x+4 && f.x<gd.x+gd.w-4;
              // below deck surface while inside the deck footprint = fell through
              if(insideX && f.y>6){
                window.__V.push({i,y:+f.y.toFixed(1),st:f.state,onG:f.onGround,vy:+f.vy.toFixed(1),vx:+f.vx.toFixed(1),onPlat:!!f.onPlatform,hl:f.hitlag,dT:f.dropThroughT,rT:f.respawnDropT});
              }
            });
          };}""", sk)
        for _ in range(14): pg.evaluate("()=>RR.step(150)"); time.sleep(0.05)
        out=pg.evaluate("()=>({n:window.__V.length, sample:window.__V.slice(0,6), st:window.__match.state, ys:window.__match.fighters.map(f=>+f.y.toFixed(1))})")
        print(f"{sk:12s} violations={out['n']:4d}  state={out['st']:5s} ys={out['ys']}")
        for l in out['sample']: print('     ', l)
    print('ERRORS', errs[:4])
    br.close()
