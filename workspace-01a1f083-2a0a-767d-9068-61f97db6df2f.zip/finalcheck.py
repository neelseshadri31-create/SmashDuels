from playwright.sync_api import sync_playwright
import time
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':860})
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.0)
    pg.screenshot(path='/tmp/f_title.png', timeout=9000)
    pg.click('#btn-vs'); time.sleep(0.6)
    pg.screenshot(path='/tmp/f_select.png', timeout=9000)
    pg.click('#sel-fight'); time.sleep(2.6)
    pg.keyboard.down('KeyD'); time.sleep(0.6); pg.keyboard.press('KeyF'); time.sleep(0.25); pg.keyboard.up('KeyD')
    pg.screenshot(path='/tmp/f_play.png', timeout=9000)
    print('errors:', errs[:5], len(errs))
    b.close()
