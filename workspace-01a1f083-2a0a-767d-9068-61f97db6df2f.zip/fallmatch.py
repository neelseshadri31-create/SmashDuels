from playwright.sync_api import sync_playwright
import time
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(1.0)
    print('state at start:', pg.evaluate("()=>window.__match.state"))
    # run the real match loop (not bypassing anything except CPU)
    pg.evaluate("""()=>{window.__YLOG=[];const m=window.__match;
      const orig=m.update.bind(m);
      m.update=function(){orig(); if(this.state==='play'&&window.__YLOG.length<4000){
        this.fighters.forEach((f,i)=>{ if(f.y>2) window.__YLOG.push({i,y:+f.y.toFixed(1),st:f.state,onG:f.onGround,vx:+f.vx.toFixed(1),vy:+f.vy.toFixed(1)}); });
      }};}""")
    # press real keys to move around and jump
    pg.keyboard.down('KeyD'); time.sleep(0.7)
    pg.keyboard.down('Space'); time.sleep(0.2); pg.keyboard.up('Space'); time.sleep(0.8)
    pg.keyboard.up('KeyD')
    pg.keyboard.down('KeyA'); time.sleep(0.9); pg.keyboard.up('KeyA')
    time.sleep(1.0)
    out=pg.evaluate("()=>({ylog:window.__YLOG.slice(0,25),n:window.__YLOG.length,st:window.__match.state})")
    print('frames below deck (y>2):', out['n'])
    for l in out['ylog']: print('  ', l)
    print('errors', errs[:4])
    br.close()
