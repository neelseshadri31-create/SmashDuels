from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw
import time
KEYS=['valor','grim','astra','vesper','rook']
STATES=[('idle','f.state="idle"'),('walk','f.state="walk";f.vx=2'),
        ('run','f.state="run";f.vx=5'),('jump','f.state="jump";f.y=-80;f.onGround=false'),
        ('attack','f.state="attack";f.action={key:"fsmash",startup:12,active:4,dur:40};f.actionT=14'),
        ('shield','f.state="shield";f.shieldHP=60')]
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.5)
    pg.evaluate("()=>{window.__match.state='play';}"); time.sleep(0.8)
    pg.evaluate("()=>{window.__match.paused=true;}")
    rows=[]
    for k in KEYS:
        cells=[]
        for sn,code in STATES:
            pg.evaluate("""([k,code])=>{const m=window.__match;
              const f=m.fighters[0];
              f.key=k;f.def=FIGHTERS[k];f.pal=FIGHTERS[k].palettes[0];f.palIdx=0;
              f.x=0;f.y=0;f.vx=0;f.vy=0;f.onGround=true;f.hitstun=0;f.hitlag=0;
              f.action=null;f.actionT=0;f.shieldHP=0;f.hitIds=new Set();
              eval(code);}""",[k,code]); time.sleep(0.14)
            v=pg.evaluate("()=>{const m=window.__match,f=m.fighters[0];const z=m.cam.zoom;return [m.W/2+z*(f.x-m.cam.x), m.H/2+z*(f.y-m.cam.y)];}")
            pg.screenshot(path='/tmp/v.png'); im=Image.open('/tmp/v.png')
            cells.append((sn, im.crop((int(v[0])-72,int(v[1])-190,int(v[0])+72,int(v[1])+20))))
        rows.append((k,cells))
    cw=144; ch=210
    mon=Image.new('RGB',(cw*len(STATES)+90, ch*len(KEYS)+26),(16,24,42))
    d=ImageDraw.Draw(mon)
    for j,(sn,_) in enumerate(STATES): d.text((90+j*cw+6,8), sn, fill=(255,240,180))
    for i,(k,cells) in enumerate(rows):
        d.text((8, 26+i*ch+90), k, fill=(160,220,255))
        for j,(sn,c) in enumerate(cells): mon.paste(c,(90+j*cw, 26+i*ch))
    mon.save('/tmp/visual_qa.png')
    print('errors',errs[:3])
    br.close()
