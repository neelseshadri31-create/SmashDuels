from playwright.sync_api import sync_playwright
import time, json
B={'left':False,'right':False,'up':False,'down':False,'attack':False,'special':False,'jump':False,'shield':False,'grab':False}
def k(**kw): return {**B,**kw}
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1000,'height':700})
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.7)
    pg.click('#btn-vs'); time.sleep(0.2); pg.click('#sel-fight'); time.sleep(0.5)
    pg.evaluate("""()=>{const m=window.__match;m.state='play';m.rules.items='none';m.updateItems=function(){};
      const c=m.fighters[1];c.ai=null;c.isCPU=false;}""")
    # bair: target BEHIND the fighter (fighter faces +1, so behind is negative x)
    r = pg.evaluate("""()=>{const m=window.__match;const a=m.fighters[0],b=m.fighters[1];
      a.x=0;a.y=-160;a.onGround=false;a.vy=0;a.facing=1;a.hitIds=new Set();a.damage=0;
      b.x=-40;b.y=-160;b.damage=0;b.hitstun=0;b.state='idle';b.shieldHP=0;b.invincT=0;b.stocks=9;
      a.startAttack('bair',m);
      for(let i=0;i<50;i++){a.readInput(%s);a.update(m);INPUT.endFrame();b.y=-160;b.vy=0;b.x=-40;}
      return Math.round(b.damage*10)/10;}""" % json.dumps(k()))
    print('bair damage on target behind:', r, '-> OK' if r>0 else '-> BROKEN')
    br.close()
