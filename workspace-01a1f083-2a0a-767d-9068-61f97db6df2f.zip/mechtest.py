from playwright.sync_api import sync_playwright
import time
FAIL=[]
def check(n,c,e=''):
    print(('PASS ' if c else 'FAIL ')+n+(' '+str(e) if e else ''))
    if not c: FAIL.append(n)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1200,'height':760})
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.8)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.5)
    pg.evaluate("()=>{const m=window.__match;m.state='play';}")

    # knockback scaling with damage
    r = pg.evaluate("""()=>{
      const m=window.__match; const a=m.fighters[0], b=m.fighters[1];
      const test=(dmg)=>{
        b.damage=0; b.x=0;b.y=0;b.vx=0;b.vy=0;b.hitstun=0;
        m.hitFighter(a,b,{damage:10,bkb:20,kbs:80,angle:45});
        return Math.round(Math.hypot(b.vx,b.vy));
      };
      const low = test(0);
      const high = (()=>{ b.damage=150; b.x=0;b.y=0;b.vx=0;b.vy=0;b.hitstun=0;
        m.hitFighter(a,b,{damage:10,bkb:20,kbs:80,angle:45});
        return Math.round(Math.hypot(b.vx,b.vy)); })();
      return {low, high};
    }""")
    check('knockback scales with damage', r['high'] > r['low']*1.8, r)

    # weight affects knockback
    r2 = pg.evaluate("""()=>{
      const m=window.__match; const a=m.fighters[0];
      const kb=(idx)=>{ const b=m.fighters[idx]; b.damage=100;b.x=0;b.y=0;b.vx=0;b.vy=0;b.hitstun=0;
        m.hitFighter(a,b,{damage:10,bkb:20,kbs:80,angle:45}); return Math.round(Math.hypot(b.vx,b.vy)); };
      return {grimWeight:m.fighters[1].weight, kb:kb(1)};
    }""")
    check('weight modifies knockback', r2['grimWeight'] > 100, r2)

    # shielding blocks damage
    r3 = pg.evaluate("""()=>{
      const m=window.__match; const a=m.fighters[0], b=m.fighters[1];
      b.damage=0; b.shieldHP=60; b.state='shield';
      m.shieldHit(a,b,10,null);
      return {dmg:Math.round(b.damage), shield:Math.round(b.shieldHP)};
    }""")
    check('shield absorbs hit', r3['dmg']==0 and r3['shield']<60, r3)

    # grab beats shield
    r4 = pg.evaluate("""()=>{
      const m=window.__match; const a=m.fighters[0], b=m.fighters[1];
      b.shieldHP=60; b.state='shield'; b.x=a.x+30; b.y=a.y; a.facing=1;
      const t=m.findGrabTarget(a);
      return {grabbed: !!t};
    }""")
    check('grab beats shield', r4['grabbed'])

    # stale move negation
    r5 = pg.evaluate("""()=>{
      const m=window.__match; const a=m.fighters[0];
      a.staleQueue=[];
      const fresh=a.staleMult('fsmash');
      for(let i=0;i<6;i++) a.pushStale('fsmash');
      const stale=a.staleMult('fsmash');
      return {fresh, stale};
    }""")
    check('stale move negation', r5['stale'] < r5['fresh'], r5)

    # Final Smash triggers
    r6 = pg.evaluate("""()=>{
      const m=window.__match; const a=m.fighters[0], b=m.fighters[1];
      a.hasSmashBall=true; a.onGround=true; a.state='idle';
      a.startFinalSmash(m);
      const active=a.finalActive>0;
      for(let i=0;i<40;i++){a.updateFinalSmash(m);}
      return {active, smoke:true};
    }""")
    check('final smash activates', r6['active'], r6)

    # blastzone KO
    r7 = pg.evaluate("""()=>{
      const m=window.__match; const b=m.fighters[1];
      b.stocks=3; b.x=WORLD.blast.right+10; b.y=0;
      b.update(m);
      return {stocks:b.stocks, state:b.state};
    }""")
    check('blastzone KO costs a stock', r7['stocks']==2, r7)

    # items spawn & pickup
    r8 = pg.evaluate("""()=>{
      const m=window.__match; const a=m.fighters[0];
      m.spawnItem('heart', a.x, a.y-40);
      const it=m.items[m.items.length-1]; it.spawnT=0;
      a.damage=80;
      const ok=m.tryPickup(a);
      return {picked:ok, dmg:Math.round(a.damage)};
    }""")
    check('healing item pickup', r8['picked'] and r8['dmg']<80, r8)

    check('no errors', len(errs)==0, errs[:3])
    b.close()
print('\nFAILURES:', FAIL)
