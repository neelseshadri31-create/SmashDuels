from playwright.sync_api import sync_playwright
import time
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':900})
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.7)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.6)
    pg.evaluate("()=>{ const m=window.__match; m.state='play'; }")
    pg.evaluate("()=>window.RR.makeAllCPU()")
    for i in range(12):
        st = pg.evaluate("()=>window.RR.step(600)")
        if st['state']!='play': break
    time.sleep(2.2)
    pg.screenshot(path='/tmp/results.png')
    print('final', st['state'], 'errors', errs[:4])
    b.close()
