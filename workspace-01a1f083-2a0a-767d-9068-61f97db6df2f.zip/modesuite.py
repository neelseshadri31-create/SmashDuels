from playwright.sync_api import sync_playwright
import time
FAIL=[]
def check(n,c,e=''):
    print(('PASS ' if c else 'FAIL ')+n+(' '+str(e) if e else ''))
    if not c: FAIL.append(n)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1360,'height':820})
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.9)

    # TARGETS: clear them by scripting hits
    pg.click('.modebtn[data-mode="targets"]'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(1.6)
    pg.evaluate("""()=>{ const m=window.__match; m.targets.forEach(t=>m.hitTargets({x:t.x-20,y:t.y-20,w:40,h:40}, m.fighters[0], 40)); }""")
    time.sleep(1.4)
    check('targets: results screen', pg.is_visible('#screen-results'))
    pg.screenshot(path='/tmp/m_targets_done.png', timeout=9000)
    pg.click('#btn-results-menu'); time.sleep(0.5)

    # HOME-RUN
    pg.click('.modebtn[data-mode="homered"]'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(1.6)
    has_bag = pg.evaluate("()=>!!window.__match.bag")
    check('homerun: sandbag exists', has_bag)
    pg.evaluate("""()=>{ const m=window.__match; m.bag.dmg=110; Modes.homeRunSwing(m); Modes.homeRunLaunch(m); }""")
    time.sleep(0.4)
    launched = pg.evaluate("()=>window.__match.bag ? window.__match.bag.launched : 'ended'")
    check('homerun: bag launches', launched is True or launched=='ended', launched)
    pg.screenshot(path='/tmp/m_homerun.png', timeout=9000)
    pg.evaluate("()=>{ const m=window.__match; if(m.bag){m.bag.x+=3000;} }")
    time.sleep(1.6)
    check('homerun: results', pg.is_visible('#screen-results'))
    pg.click('#btn-results-menu'); time.sleep(0.5)

    # MULTI-MAN
    pg.click('.modebtn[data-mode="multiman"]'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(2.2)
    mm = pg.evaluate("()=>({mm: !!window.__match.multiman, mobs: window.__match.fighters.filter(f=>f.isMob).length})")
    check('multiman: state + mob', mm['mm'], mm)
    pg.screenshot(path='/tmp/m_multiman.png', timeout=9000)
    pg.click('#btn-pause'); time.sleep(0.3); pg.click('#btn-quit'); time.sleep(0.5)

    # CLASSIC
    pg.click('.modebtn[data-mode="classic"]'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(1.8)
    cl = pg.evaluate("()=>({mode: window.__match.opts.metaMode||'?', fighters: window.__match.fighters.length, stage: window.__match.stage.key})")
    check('classic: starts stage 1', cl['fighters']==2, cl)
    # force a win
    pg.evaluate("""()=>{ const m=window.__match; m.fighters.slice(1).forEach(f=>{f.stocks=0;f.eliminated=true;}); m.endMatch(); }""")
    time.sleep(2.8)
    st2 = pg.evaluate("()=>({stage: window.__match.stage.key, fighters: window.__match.fighters.length, state: window.__match.state})")
    check('classic: advances to stage 2', st2['state'] in ('intro','play'), st2)
    pg.screenshot(path='/tmp/m_classic2.png', timeout=9000)
    check('no runtime errors', len(errs)==0, errs[:3])
    b.close()
print('\nFAILURES:', FAIL)
