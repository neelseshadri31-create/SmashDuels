from playwright.sync_api import sync_playwright
import time
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':860})
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.9)
    pg.click('#btn-vs'); time.sleep(0.3)
    pg.click('#add-slot'); time.sleep(0.2); pg.click('.fcell[data-key="astra"]'); time.sleep(0.2)
    pg.click('#add-slot'); time.sleep(0.2); pg.click('.fcell[data-key="rook"]'); time.sleep(0.2)
    pg.click('#sel-fight'); time.sleep(3.0)
    pg.screenshot(path='/tmp/s1.png')
    time.sleep(2.5); pg.screenshot(path='/tmp/s2.png')
    pg.keyboard.down('KeyD'); time.sleep(0.5); pg.keyboard.press('KeyF'); time.sleep(0.3); pg.keyboard.up('KeyD')
    pg.screenshot(path='/tmp/s3.png')
    b.close()
print('errors', errs[:5], len(errs))
