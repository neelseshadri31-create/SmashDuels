from PIL import Image, ImageDraw
import numpy as np, json, os
os.makedirs('game/assets/portraits', exist_ok=True)
os.makedirs('game/assets/fx', exist_ok=True)

SHEETS = {
 'valor': dict(path='roster/valor_the_swordsman_spritesheet.png', taunt=(848, 940),
               slots=[(8,92),(95,175),(185,268),(272,352),(360,458),(462,548)],
               fx=(880, 1000, 870, 1060)),
 'grim':  dict(path='roster/grim_the_colossus_spritesheet.png', taunt=(700, 778),
               slots=[(8,92),(95,180),(185,282),(286,368),(372,458),(462,548)],
               fx=(742, 806, 700, 880)),
 'astra': dict(path='roster/astra_the_starweaver_spritesheet.png', taunt=(678, 775),
               slots=[(5,95),(95,185),(185,285),(285,370),(370,462),(462,556)],
               fx=(745, 806, 700, 880)),
 'vesper':dict(path='roster/vesper_the_shade_spritesheet.png', taunt=(688, 775),
               slots=[(5,95),(95,185),(185,285),(285,370),(370,462),(462,556)],
               fx=(745, 806, 700, 880)),
 'rook':  dict(path='roster/rook_the_hexshot_spritesheet.png', taunt=(672, 772),
               slots=[(5,95),(95,185),(185,285),(285,370),(370,462),(462,556)],
               fx=(745, 806, 700, 880)),
}

def trim(im):
    a = np.array(im.convert('RGB')).astype(int)
    m = a.max(axis=2) > 40
    ys, xs = np.where(m)
    if len(xs) == 0: return None
    return im.crop((xs.min(), ys.min(), xs.max()+1, ys.max()+1))

mon = Image.new('RGB', (6*120, 5*150+30), (14,16,22)); d = ImageDraw.Draw(mon)
out = {}
for r,(key, cfg) in enumerate(SHEETS.items()):
    im = Image.open(cfg['path']).convert('RGB')
    y0,y1 = cfg['taunt']
    poses = []
    for i,(x0,x1) in enumerate(cfg['slots']):
        c = trim(im.crop((x0, y0, x1, y1)))
        if c is None: continue
        c.save(f'game/assets/portraits/{key}_pose{i}.png')
        t = c.copy(); t.thumbnail((105,135), Image.LANCZOS)
        mon.paste(t, (i*120+8, r*150+25))
        poses.append(f'{key}_pose{i}.png')
    # bust portrait from pose0: top 58%
    p0 = Image.open(f'game/assets/portraits/{key}_pose0.png')
    bust = p0.crop((0,0,p0.width, int(p0.height*0.60)))
    bust = bust.resize((bust.width*3, bust.height*3), Image.LANCZOS)
    bust.save(f'game/assets/portraits/{key}_bust.png')
    # fx spark
    fy0,fy1,fx0,fx1 = cfg['fx']
    band = im.crop((fx0,fy0,fx1,fy1))
    a = np.array(band).astype(int); m = a.max(axis=2) > 90
    # biggest bright blob
    from collections import deque
    h,w = m.shape; seen=np.zeros_like(m,bool); best=None
    for yy in range(h):
        for xx in range(w):
            if m[yy,xx] and not seen[yy,xx]:
                q=deque([(yy,xx)]); seen[yy,xx]=True; cell=[]
                while q:
                    cy,cx=q.popleft(); cell.append((cy,cx))
                    for dy in(-1,0,1):
                        for dx in(-1,0,1):
                            ny,nx=cy+dy,cx+dx
                            if 0<=ny<h and 0<=nx<w and m[ny,nx] and not seen[ny,nx]:
                                seen[ny,nx]=True; q.append((ny,nx))
                if best is None or len(cell)>len(best): best=cell
    if best:
        ys=[c[0] for c in best]; xs=[c[1] for c in best]
        sp = trim(band.crop((min(xs)-2,min(ys)-2,max(xs)+3,max(ys)+3)))
        if sp: sp.save(f'game/assets/fx/{key}_spark.png')
    out[key] = poses
    d.text((6, r*150+6), f'{key}  poses={len(poses)}', fill=(150,215,255))
mon.save('/tmp/poses_check.png')
json.dump(out, open('game/assets/portraits/poses.json','w'), indent=1)
print(json.dumps(out))
