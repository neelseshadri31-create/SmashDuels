from playwright.sync_api import sync_playwright
import time
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    pg.click('#btn-vs'); time.sleep(0.3); pg.click('#sel-fight'); time.sleep(0.6)
    pg.evaluate("()=>{window.__match.state='play';}")
    time.sleep(1.0)
    for state,setup in [
      ("idle","f.state='idle';f.vx=0;f.vy=0;"),
      ("walk","f.state='walk';f.vx=2;"),
      ("run","f.state='run';f.vx=5;"),
    ]:
        seq=[]
        for k in range(14):
            seq.append(pg.evaluate("""(setup)=>{const m=window.__match;const f=m.fighters[0];
              f.x=0;f.y=0;f.onGround=true;f.action=null;eval(setup);
              const dt=m.time - (window.__lastT||m.time); window.__lastT=m.time;
              return {pick:Sprites.pickFrame(f,m.time), dt:+dt.toFixed(0)};}""", setup))
            time.sleep(0.1)
        print(state, [s['pick'] for s in seq])
    br.close()
