from playwright.sync_api import sync_playwright
import time
B = {'left':False,'right':False,'up':False,'down':False,'attack':False,'special':False,'jump':False,'shield':False,'grab':False}
def k(**kw): return {**B, **kw}
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1000,'height':700})
    pg.on('pageerror',lambda e: print('ERR',e))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.7)
    pg.click('#btn-vs'); time.sleep(0.2); pg.click('#sel-fight'); time.sleep(0.5)
    pg.evaluate("""()=>{const m=window.__match;m.state='play';m.rules.items='none';const c=m.fighters[1];c.ai=null;c.isCPU=false;c.x=900;}""")
    for frames in [6, 10, 14, 20]:
        pg.evaluate("""()=>{const f=window.__match.fighters[0];
          f.x=0;f.y=0;f.vx=0;f.vy=0;f.state='idle';f.action=null;f.hitstun=0;f.hitlag=0;f.onGround=true;
          f.inputBuffer={attack:0,special:0,jump:0,shield:0,grab:0};f.prevInput={};f.dirTapT={left:99,right:99,up:99,down:99};
          f.shieldHP=0;f.facing=1;}""")
        pg.evaluate("([r,n])=>window.RR.feed(r,n)", [k(right=True), frames])
        d = pg.evaluate("""()=>{const f=window.__match.fighters[0];
          return {vx:+f.vx.toFixed(2), walk:f.def.stats.walk, thr:+(f.def.stats.walk*1.55).toFixed(2),
                  dirTap:JSON.parse(JSON.stringify(f.dirTapT)), state:f.state, onG:f.onGround};}""")
        print(f'after {frames}f right:', d)
        d2 = pg.evaluate("([r,n])=>window.RR.feed(r,n)", [k(right=True, attack=True), 1])
        print('   +attack ->', d2['act'])
    br.close()
