from playwright.sync_api import sync_playwright
import time, json
errs=[]
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1440,'height':860})
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.0)
    pg.click('#btn-vs'); time.sleep(0.25); pg.click('#sel-fight'); time.sleep(0.4)
    pg.evaluate("()=>{const m=window.__match;m.state='play';m.rules.items='none';const c=m.fighters[1];c.ai=null;c.isCPU=false;c.x=400;m.updateItems=function(){};}")
    time.sleep(0.6)
    print(pg.evaluate("()=>{const m=window.__match,f=m.fighters[0],c=m.camera;return {fx:f.x,fy:f.y,cam:JSON.stringify(c),proj:JSON.stringify(m.toScreen?m.toScreen(f.x,f.y):null)};}"))
    pg.screenshot(path='/tmp/a_full.png')
    br.close()
print(errs[:3])
