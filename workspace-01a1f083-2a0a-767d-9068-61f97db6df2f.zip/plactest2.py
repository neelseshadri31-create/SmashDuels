from playwright.sync_api import sync_playwright
import time, json
res=[]
def log(n,ok,info=''): res.append((n,ok,info)); print(('PASS' if ok else 'FAIL'),n,info)

with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    def start(stage):
        pg.evaluate("""(sk)=>{const cast=[{key:'valor',palIdx:0,isCPU:false,team:0},{key:'grim',palIdx:0,isCPU:true,team:1}];
          Game.startMatch({rules:{...DEFAULT_RULES,mode:'classic',items:'none',stock:3,time:300},cast,stageKey:sk,metaMode:null});
          const m=window.__match; m.state='play';
          m.fighters[1].ai=null; m.fighters[1].isCPU=false; m.fighters[1].x=900;
          m.updateItems=function(){}; m.rules.items='none';}""", stage); time.sleep(0.55)

    # ---- spawns across all stages, 4 players
    for sk in ['skyshrine','terminal','foundry','cometreach','hollow','range']:
        r=pg.evaluate("""(sk)=>{const cast=['valor','grim','astra','vesper'].map((k,i)=>({key:k,palIdx:i,isCPU:i>0,team:0}));
          Game.startMatch({rules:{...DEFAULT_RULES,mode:'classic',items:'none',stock:3,time:300},cast,stageKey:sk,metaMode:null});
          const m=window.__match;m.state='play';m.updateItems=function(){};
          m.fighters.forEach(f=>{f.ai=null;f.isCPU=false;});
          for(let k=0;k<6;k++)m.fighters.forEach(f=>f.update(m));
          const g=m.stage.ground;
          const out=m.fighters.map(f=>({x:+f.x.toFixed(1),y:+f.y.toFixed(1),st:f.state,onG:f.onGround}));
          const onStage=out.every(o=> o.x>g.x+8 && o.x<g.x+g.w-8 && Math.abs(o.y-0)<3);
          let overlap=false;
          for(let a=0;a<out.length;a++)for(let b=a+1;b<out.length;b++) if(Math.abs(out[a].x-out[b].x)<12) overlap=true;
          return {out,onStage,overlap,g:'['+g.x+','+(g.x+g.w)+']'};}""", sk)
        log(f"C1/C2 spawns on stage, no overlap [{sk}]", r['onStage'] and not r['overlap'], r['g']+' '+json.dumps(r['out']))

    # ---- C9 moving platform carry (cometreach has vertical movers)
    start('cometreach')
    r=pg.evaluate("""()=>{const m=window.__match,f=m.fighters[0];
        const p=m.stage.platforms.find(pp=>pp.move);
        f.x=p.cx!==undefined?p.cx:p.x; f.y=(p.cy!==undefined?p.cy:p.y);
        f.vy=0;f.vx=0;f.onGround=true;f.onPlatform=m.stage.platforms.indexOf(p);
        f.x = (p.cx!==undefined?p.cx:p.x); f.y = (p.cy!==undefined?p.cy:p.y);
        const y0=p.cy!==undefined?p.cy:p.y, fy0=f.y;
        const dy0=p.cy!==undefined?p.cy:p.y;
        for(let k=0;k<120;k++){ m.stage.update ? m.stage.update(1/60) : null; f.update(m); }
        const py=(p.cy!==undefined?p.cy:p.y);
        return {platY:+py.toFixed(1),fighterY:+f.y.toFixed(1),onG:f.onGround,plat:f.onPlatform,deltaP:+(py-dy0).toFixed(1),deltaF:+(f.y-fy0).toFixed(1),st:f.state};}""")
    carried = abs(r['deltaF']-r['deltaP'])<3.5
    log("C9 moving platform carries rider", carried, str(r))

    # ---- drop-through: down on a soft platform
    start('skyshrine')
    r=pg.evaluate("""()=>{const m=window.__match,f=m.fighters[0],p=m.stage.platforms[0];
        f.x=p.x;f.y=p.y-120;f.vx=0;f.vy=2;f.onGround=false;f.onPlatform=-1;f.state='fall';
        for(let k=0;k<40;k++)f.update(m);
        const landed=+f.y.toFixed(1), landedOn=f.onPlatform;
        if(!landedOn) return {err:'never landed on platform',y:landed};
        let dropped=false;
        let firstDown=true;
        for(let k=0;k<40;k++){ f.readInput({down:true}); f.update(m); INPUT.endFrame();
          if(!f.onPlatform&&f.y>landed+8){dropped=true;break;} }
        return {landed,landedOn:!!landedOn,dropped,y:+f.y.toFixed(1),st:f.state,onG:f.onGround};}""")
    log("C3b down = drop through soft platform", r['dropped'], str(r))

    # ---- C6 respawn pos after KO
    r=pg.evaluate("""()=>{const m=window.__match,f=m.fighters[0];
        f.stocks=3; f.eliminated=false; f.damage=0;
        f.x=m.stage.ground.x+m.stage.ground.w+700; f.y=-40; f.vy=0;
        for(let k=0;k<30;k++)f.update(m);
        const afterKO={elim:f.eliminated,dt:+f.respawnT.toFixed(0),x:+f.x.toFixed(1),y:+f.y.toFixed(1),st:f.state};
        for(let k=0;k<200;k++)f.update(m);
        return {afterKO, now:{x:+f.x.toFixed(1),y:+f.y.toFixed(1),st:f.state,onG:f.onGround,inv:+f.invincT.toFixed(0)}};}""")
    ok = r['afterKO']['elim'] or r['afterKO']['dt']>0
    log("C6 blast-zone KO triggers respawn", ok, str(r))
    inb = pg.evaluate("(x)=>{const g=window.__match.stage.ground;return x>g.x+40&&x<g.x+g.w-40;}", r['now']['x'])
    log("C6b respawn lands inside stage footprint", inb and abs(r['now']['y'])<4 and r['now']['onG'], str(r['now']))

    # ---- C10 ledge grab
    r=pg.evaluate("""()=>{const m=window.__match,f=m.fighters[0],g=m.stage.ground;
        f.x=g.x+g.w/2; f.y=-30; f.vx=0; f.vy=4; f.state='fall'; f.onGround=false; f.onPlatform=-1; f.ledge=null; f.hitstun=0;
        let grabbed=false;
        for(let k=0;k<160;k++){
          // steer right toward the right ledge and fall past it
          f.readInput({right:k>20, down:k<5}); f.update(m); INPUT.endFrame();
          if(f.state==='ledge'){ grabbed=true; break; }
        }
        return {grabbed,st:f.state,x:+f.x.toFixed(1),y:+f.y.toFixed(1),ledge:JSON.stringify(f.ledge)};}""")
    log("C10 ledge grab reachable off-stage", r['grabbed'], str(r))
    print('ERRS', errs[:3])
    br.close()
print('\n== SUMMARY =='); 
for n,ok,_ in res: print(('PASS' if ok else 'FAIL'),n)
