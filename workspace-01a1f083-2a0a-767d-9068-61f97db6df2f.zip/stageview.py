from playwright.sync_api import sync_playwright
from PIL import Image
import time
STAGES=['skyshrine','terminal','foundry','cometreach','hollow','range']
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.2)
    shots=[]
    for sk in STAGES:
        pg.evaluate("""(sk)=>{const cast=[{key:'valor',palIdx:0,isCPU:false,team:0},{key:'grim',palIdx:0,isCPU:true,team:1}];
          Game.startMatch({rules:{...DEFAULT_RULES,mode:'classic',items:'none',stock:3,time:300},cast,stageKey:sk,metaMode:null});
          const m=window.__match;m.state='play';
          m.fighters[1].ai=null;m.fighters[1].isCPU=false;
          m.fighters[0].x=-150;m.fighters[1].x=150;m.fighters[0].y=0;m.fighters[1].y=0;}""", sk)
        time.sleep(1.5)
        p2=f'/tmp/st_{sk}.png'; pg.screenshot(path=p2); shots.append((sk,p2))
    # montage 2x3
    ims=[(k,Image.open(pth).resize((640,380))) for k,pth in shots]
    mon=Image.new('RGB',(1280,1140),(10,14,24))
    for i,(k,im) in enumerate(ims):
        mon.paste(im,((i%2)*640,(i//2)*380))
    mon.save('/tmp/stages6.png')
    print('errors',errs[:3])
    br.close()
