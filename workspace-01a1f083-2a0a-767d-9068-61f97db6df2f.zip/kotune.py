from playwright.sync_api import sync_playwright
import time, sys
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.0)
    pg.click('#btn-vs'); time.sleep(0.25); pg.click('#sel-fight'); time.sleep(0.4)
    r=pg.evaluate("""()=>{const m=window.__match;m.state='play';m.rules.items='none';m.updateItems=function(){};
      const a=m.fighters[0],b=m.fighters[1];b.ai=null;b.isCPU=false;
      const reset=(dmg)=>{
        for(const f of [a,b]){ f.eliminated=false; f.stocks=3; f.respawnT=0; f.respawnDropT=0; f.spawnProtect=0; f.invincT=0; f.hitlag=0; f.hitstun=0; f.stunT=0; f.action=null; f.state='idle'; f.charging=false; f.chargeT=0; f.forceRelease=false; f.shieldHP=0; f.vx=0; f.vy=0; f.actionT=0; f.onGround=true; f.onPlatform=null; }
        a.x=0;a.y=0;a.facing=1;a.hitIds=new Set();a.prevInput={};a.inputBuffer={attack:0,special:0,jump:0,shield:0,grab:0};
        b.x=52;b.y=0;b.damage=dmg;b.prevInput={};
      };
      const ko=(dmg)=>{
        reset(dmg);
        a.readInput({attack:true}); a.startAttack('fsmash',m);
        let vx=0;
        for(let k=0;k<60;k++){a.readInput({attack:k<2});a.update(m);b.update(m);INPUT.endFrame(); if(b.hitstun>0){vx=Math.hypot(b.vx,b.vy);break;}}
        let kos=false,frames=0, dieX=0;
        for(let k=0;k<600;k++){ const raw=b.x>0?{left:true}:{right:true}; b.readInput(raw); b.update(m); INPUT.endFrame(); frames++; if(b.stocks<3){kos=true;dieX=Math.round(b.x);break;} }
        return {dmg,v:+vx.toFixed(1),kos,x:dieX};
      };
      return [0,30,60,80,100,120,150,200].map(d=>ko(d));}""")
    for l in r: print(l)
    br.close()
