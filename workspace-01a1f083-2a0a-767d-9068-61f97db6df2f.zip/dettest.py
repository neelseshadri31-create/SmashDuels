from playwright.sync_api import sync_playwright
import time, json
RES=[]
def t(n, ok, e=''):
    RES.append((n,ok,e)); print(('PASS ' if ok else 'FAIL ')+n+('  '+str(e) if e else ''))

B = {'left':False,'right':False,'up':False,'down':False,'attack':False,'special':False,'jump':False,'shield':False,'grab':False}
def k(**kw): return {**B, **kw}

with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1200,'height':760})
    errs=[]; pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.7)
    pg.click('#btn-vs'); time.sleep(0.2); pg.click('#sel-fight'); time.sleep(0.5)
    # isolate: no items, no hazards, park the CPU far away and disable it
    pg.evaluate("""()=>{const m=window.__match;m.state='play';m.rules.items='none';m.rules.hazards=false;
      const c=m.fighters[1]; c.ai=null; c.isCPU=false; c.x=900; c.y=0; c.stocks=99;
      m.updateItems=function(){}; }""")

    def fresh():
        pg.evaluate("""()=>{const m=window.__match;const f=m.fighters[0];
          f.x=0;f.y=0;f.vx=0;f.vy=0;f.state='idle';f.action=null;f.actionT=0;f.hitstun=0;f.hitlag=0;
          f.onGround=true;f.onPlatform=null;f.dropThroughT=0;f.facing=1;f.damage=0;
          f.inputBuffer={attack:0,special:0,jump:0,shield:0,grab:0};f.prevInput={};
          f.dirTapT={left:99,right:99,up:99,down:99};f.shieldHP=0;f.shieldT=0;f.shieldStun=0;f.stunT=0;
          f.airJumpsLeft=f.def.stats.airJumps;f.jumpsLeft=f.def.stats.jumps;f.usedUpB=false;f.usedAirDodge=false;
          f.fastfalled=false;f.cooldowns={};f.chargeT=0;f.charging=false;f.finalActive=0;f.ledge=null;f.grabbedBy=null;
          f.grabbing=null;f.buffs={star:0,mushroom:0,poison:0,metal:0,bunny:0,flower:0};
          f.staleQueue=[];f.pendingSpecial=null;f.respawnT=0;f.invincT=0;f.jumpHoldT=0;}""")
    def feed(raw, n):
        return pg.evaluate("([r,n])=>window.RR.feed(r,n)", [raw, n])

    # ---- BASIC GROUND ATTACKS
    fresh(); d = feed(k(attack=True), 1)
    t('jab 1 frame', d['act'] and d['act']['key']=='jab', d['act'])

    fresh(); feed(k(right=True), 6); d = feed(k(right=True, attack=True), 1)
    t('ftilt (hold right + attack)', d['act'] and d['act']['key'] in ('ftilt','dashattack'), d['act'])

    fresh(); feed(k(right=True), 14); d = feed(k(right=True, attack=True), 1)
    t('running + attack = dash attack', d['act'] and d['act']['key']=='dashattack', d['act'])

    fresh(); feed(k(up=True), 1); d = feed(k(up=True, attack=True), 1)
    t('utilt (hold up + attack)', d['act'] and d['act']['key'] in ('utilt','usmash'), d['act'])

    fresh(); feed(k(down=True), 2); d = feed(k(down=True, attack=True), 1)
    t('dtilt (hold down + attack)', d['act'] and d['act']['key'] in ('dtilt','dsmash'), d['act'])

    fresh(); d = feed(k(attack=True), 1); d2 = feed(k(attack=True), 30)
    t('attack returns to idle after animation', d2['st'] in ('idle','walk'), d2['st'])

    # ---- AERIALS
    fresh()
    pg.evaluate("()=>{const f=window.__match.fighters[0];f.y=-200;f.onGround=false;f.vy=0;f.state='air';}")
    d = feed(k(attack=True), 1)
    t('nair (air, no direction)', d['act'] and d['act']['key']=='nair', d['act'])
    for name, raw in [('fair', k(right=True,attack=True)), ('bair', k(left=True,attack=True)),
                      ('uair', k(up=True,attack=True)), ('dair', k(down=True,attack=True))]:
        fresh(); pg.evaluate("()=>{const f=window.__match.fighters[0];f.y=-200;f.onGround=false;f.vy=0;f.state='air';f.facing=1;}")
        d = feed(raw, 1)
        t(f'{name} in air', d['act'] and d['act']['key']==name, d['act'])

    # ---- SPECIALS
    for name, raw in [('neutral', k(special=True)), ('side', k(right=True,special=True)),
                      ('up', k(up=True,special=True)), ('down', k(down=True,special=True))]:
        fresh(); d = feed(raw, 1)
        if d['st']!='special':
            d = feed(raw, 2)
        t(f'special {name}', d['st']=='special', {'st':d['st'],'act':d['act'],'buf':d['buf']})

    # ---- GRAB
    fresh(); d = feed(k(grab=True), 1)
    t('grab button works', d['st']=='grab', {'st':d['st'],'buf':d['buf']})

    # ---- JUMP
    fresh(); d = feed(k(jump=True), 1)
    t('jump starts', d['vy'] < -5, {'vy':d['vy'],'st':d['st']})
    d2 = feed(k(jump=True), 1)
    d3 = feed(k(), 1)
    j2 = feed(k(jump=True), 1)
    t('double jump after 2nd press', j2['vy'] < -3 or j2['st']=='doublejump', {'vy':j2['vy'],'jumps':j2.get('buf')})
    d = feed(k(), 48)
    t('lands back on ground', d['onG'], {'y':d['y'],'onG':d['onG']})

    # ---- SHIELD / ROLL / SPOTDODGE
    fresh(); d = feed(k(shield=True), 2)
    t('shield raises', d['st']=='shield', d['st'])
    fresh(); d = feed(k(shield=True), 2); d = feed(k(shield=True, down=True), 2)
    t('shield+down = spotdodge', d['st']=='spotdodge', d['st'])
    fresh(); d = feed(k(shield=True), 2); d = feed(k(shield=True, right=True), 2)
    t('shield+dir = roll', d['st']=='roll', d['st'])

    # ---- shield does not linger
    d = feed(k(), 30)
    t('shield drops when released', d['st'] in ('idle','walk','land'), d['st'])

    print('\nerrors:', errs[:5])
    br.close()
print('\n=== FAILED ===')
for n,ok,e in RES:
    if not ok: print(' -', n, e)
print('total',len(RES),'failed',sum(1 for _,o,_ in RES if not o))
