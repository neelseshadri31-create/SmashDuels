from playwright.sync_api import sync_playwright
import time
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1440,'height':860})
    pg.on('pageerror',lambda e: errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.8)
    pg.click('#btn-vs'); time.sleep(0.3)
    pg.click('#sel-fight'); time.sleep(2.5)

    def snap(tag):
        pg.screenshot(path=f'/tmp/d_{tag}.png')
    # fight: approach and mash attacks
    for r in range(3):
        pg.keyboard.down('KeyD'); time.sleep(0.7); pg.keyboard.up('KeyD')
        for _ in range(3):
            pg.keyboard.press('KeyF'); time.sleep(0.22)
        pg.keyboard.down('KeyW'); pg.keyboard.press('KeyF'); pg.keyboard.up('KeyW'); time.sleep(0.35)
        snap(f'atk{r}')
    time.sleep(1.5)
    snap('after')
    # summarize match state via DOM (damage % text)
    dmg = pg.eval_on_selector_all('.hud-slot .pct','els=>els.map(e=>e.textContent)')
    print('damage %:', dmg)
    time.sleep(4)
    dmg2 = pg.eval_on_selector_all('.hud-slot .pct','els=>els.map(e=>e.textContent)')
    print('damage % later:', dmg2)
    snap('later')
    b.close()
print('errors', errs[:8], len(errs))
