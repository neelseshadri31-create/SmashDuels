from playwright.sync_api import sync_playwright
import time, json
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':800})
    pg.on('pageerror',lambda e: print('ERR', e))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(0.7)
    pg.click('#btn-vs'); time.sleep(0.3)
    pg.click('#sel-fight'); time.sleep(2.5)
    for _ in range(6):
        info = pg.evaluate("""()=>{
          const m = window.__match;
          return {state:m.state, frame:m.frame,
            f: m.fighters.map(f=>({k:f.key, x:Math.round(f.x), y:Math.round(f.y), st:f.state, dmg:Math.round(f.damage), hl:f.hitstun, cpu:!!f.ai, plan:f.ai?f.ai.plan:'-'}))};
        }""")
        print(json.dumps(info))
        pg.keyboard.down('KeyD'); time.sleep(0.4)
        pg.keyboard.press('KeyF'); time.sleep(0.4); pg.keyboard.up('KeyD')
        time.sleep(0.4)
    b.close()
