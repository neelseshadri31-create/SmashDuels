from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw
import time
KEYS=['valor','grim','astra','vesper','rook']
with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1440,'height':860})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.0)
    pg.click('#btn-vs'); time.sleep(0.25); pg.click('#sel-fight'); time.sleep(0.5)
    pg.evaluate("()=>{const m=window.__match;m.state='play';m.rules.items='none';const c=m.fighters[1];c.ai=null;c.isCPU=false;c.x=420;m.updateItems=function(){};}")
    time.sleep(1.2); pg.evaluate("()=>{window.__match.paused=true;}")
    rows=[]
    for pal in [0,1,2,3]:
        crops=[]
        for k in KEYS:
            pg.evaluate("""([k,pal])=>{const m=window.__match;
              m.fighters.forEach(f=>{f.x=900;f.y=0;});
              let f=m.fighters[0];
              f.key=k; f.def=FIGHTERS[k]; f.palIdx=pal; f.pal=FIGHTERS[k].palettes[pal];
              f.x=0;f.y=0;f.state='attack';f.action={key:'fsmash',startup:12,active:4,dur:40};f.actionT=14;f.facing=1;f.onGround=true;f.hitstun=0;
            }""",[k,pal]); time.sleep(0.16)
            v=pg.evaluate("()=>{const m=window.__match,f=m.fighters[0];const z=m.cam.zoom;return [m.W/2+z*(f.x-m.cam.x), m.H/2+z*(f.y-m.cam.y)];}")
            pg.screenshot(path='/tmp/s.png'); im=Image.open('/tmp/s.png')
            crops.append(im.crop((int(v[0])-70,int(v[1])-175,int(v[0])+70,int(v[1])+15)))
        rows.append(crops)
    cw,ch=rows[0][0].size
    W=cw*len(rows[0]); H=ch*len(rows)
    mon=Image.new('RGB',(W,H),(18,28,48))
    for ri,crops in enumerate(rows):
        for ci,c in enumerate(crops): mon.paste(c,(ci*cw, ri*ch))
    mon.save('/tmp/roster_pal.png')
    print('errs',errs[:3])
    br.close()
