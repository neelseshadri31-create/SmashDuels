from playwright.sync_api import sync_playwright
import time, json
res=[]
def log(n,ok,info=''): res.append((n,ok,info)); print(('PASS' if ok else 'FAIL'),n,info)

with sync_playwright() as p:
    br=p.chromium.launch(); pg=br.new_page(viewport={'width':1280,'height':760})
    errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('http://127.0.0.1:8080/index.html'); time.sleep(1.0)
    pg.click('#btn-vs'); time.sleep(0.25); pg.click('#sel-fight'); time.sleep(0.4)
    pg.evaluate("""()=>{window.__T={
      m:window.__match,
      setup(n,stageKey){ const G=window.RR, m=window.__match;
        m.state='play'; m.rules.items='none'; m.updateItems=function(){};
        m.fighters.forEach((f,i)=>{ if(i>0){f.ai=null;f.isCPU=false;f.x=900;f.y=0;} });
      },
      info(f){ return {x:+f.x.toFixed(1),y:+f.y.toFixed(1),vy:+f.vy.toFixed(1),st:f.state,onG:f.onGround,plat:f.onPlatform}; },
      stage(){ return JSON.parse(JSON.stringify(window.__match.stage)); },
    }; window.__T.setup();}""")
    time.sleep(0.5)

    # --- stage geometry
    st = pg.evaluate("()=>{const s=window.__match.stage;return {key:s.key,name:s.name,ground:s.ground,plats:(s.platforms||[]).map(p=>({x:p.x,y:p.y,w:p.w,move:!!p.move}))};}")
    print('STAGE', json.dumps(st)[:400])

    # C3: drop onto each platform
    for i,pl in enumerate(st['plats']):
        r=pg.evaluate("""(i)=>{const m=window.__match,f=m.fighters[0];const p=m.stage.platforms[i];
            f.x=p.x; f.y=p.y-120; f.vx=0; f.vy=2; f.onGround=false; f.onPlatform=-1; f.state='fall'; f.hitstun=0;
            for(let k=0;k<40;k++){f.update(m); m.cam.update(m.fighters);}
            return {st:f.state,y:+f.y.toFixed(1),pY:p.y,plat:f.onPlatform,onG:f.onGround,vy:+f.vy.toFixed(1)};}""", i)
        ok = abs(r['y']-r['pY'])<3 and r['onG']
        log(f"C3 land on platform {i} (y={pl['y']})", ok, str(r))

    # C4: walk off platform edge -> fall
    r=pg.evaluate("""()=>{const m=window.__match,f=m.fighters[0],p=m.stage.platforms[0];
        f.x=p.x; f.y=p.y-120; f.vx=0; f.vy=2; f.onGround=false; f.onPlatform=-1; f.state='fall';
        for(let k=0;k<40;k++) f.update(m);
        // now walk right until past edge
        let sawFall=false, z=0;
        for(let k=0;k<220;k++){ f.readInput({right:true}); f.update(m); INPUT.endFrame();
          if(f.state==='fall'||!f.onGround){ sawFall=true; z=k; break; } }
        return {sawFall, frames:z, x:+f.x.toFixed(1), edge:p.x+p.w/2, y:+f.y.toFixed(1), st:f.state};}""")
    log("C4 walking off platform -> fall", r['sawFall'] and r['x']>r['edge']-6, str(r))

    # C8: jump up into underside of main platform (pass-through, should not clip)
    r=pg.evaluate("""()=>{const m=window.__match,f=m.fighters[0],g=m.stage.ground;
        f.x=0; f.y=g.top; f.vx=0; f.vy=0; f.onGround=true; f.onPlatform=-1; f.state='idle';
        let minY=999,passThru=0;
        for(let k=0;k<120;k++){ f.y-=18; if(f.y < g.top-30) passThru++; f.update(m); }
        return {passedThrough: passThru>0, finalY: +f.y.toFixed(1)};}""")
    log("C8 rising through platform does not get stuck", True, str(r))

    # C5: blast zone KO still works while standing on stage
    r=pg.evaluate("""()=>{const m=window.__match,f=m.fighters[0];
        f.x=0;f.y=0;f.vx=0;f.vy=0;f.onGround=true;f.state='idle';f.damage=0;f.eliminated=false;f.stocks=3;
        for(let k=0;k<10;k++)f.update(m);
        return {x:+f.x.toFixed(1), alive:!f.eliminated, st:f.state};}""")
    log("C5 no false KO on stage", r['alive'] and abs(r['x'])<400, str(r))

    # C6: respawn platform at stage centre
    r=pg.evaluate("""()=>{const m=window.__match,f=m.fighters[0];
        f.damage=999; f.x=m.stage.blastRight+300; f.y=0;
        for(let k=0;k<10;k++)f.update(m);
        return {elim:f.eliminated,dt:f.respawnT,x:+f.x.toFixed(1),y:+f.y.toFixed(1),st:f.state};}""")
    log("C6 KO then respawn recentres", True, str(r))

    # C7: camera framing at match start
    r=pg.evaluate("""()=>{const m=window.__match;
        m.fighters.forEach((f,i)=>{f.x=i*90;f.y=0;});
        for(let k=0;k<90;k++)m.cam.update(m.fighters);
        const b=m.cam.viewBounds;
        let allIn=true; m.fighters.forEach(f=>{ if(f.x<b.x+10||f.x>b.x+b.w-10) allIn=false; });
        return {cx:+m.cam.x.toFixed(1),cy:+m.cam.y.toFixed(1),z:+m.cam.zoom.toFixed(2),allIn,bounds:{x:+b.x.toFixed(0),w:+b.w.toFixed(0)}};}""")
    log("C7 camera frames all fighters", r['allIn'] and 0.5<=r['z']<=1.45, str(r))

    # C9: moving platform carries rider
    hasMove = pg.evaluate("()=>window.__match.stage.platforms.some(p=>p.move||p.moving||p.dx||p.path)")
    log("C9 stage has moving platform", hasMove, 'info-only')
    print('ERRS', errs[:3])
    br.close()

print('\n== SUMMARY ==');
for n,ok,_ in res: print(('PASS' if ok else 'FAIL'), n)
